/* Deterministic input lockstep for linked GBA sessions.
 *
 * Every device runs the SAME simulation (all N linked GBAs, joined by mGBA's
 * virtual link cable) from the same starting state. Only button presses cross
 * the network. A frame is simulated only when the presses of every seat for
 * that frame are known, so all devices stay bit-identical while each one renders
 * locally at full quality. Presses are scheduled `delay` frames ahead to hide
 * network latency (like fighting-game netplay).
 *
 * Topology: star. Guests send their presses to the host; the host relays them.
 * The host also publishes presses for seats it owns on behalf of "stream"
 * guests (devices that watch a video stream instead of running the game).
 *
 * Pure logic: engine and transport are injected, so this file runs in a browser
 * and in Node tests.
 */
(function (root) {
  const HISTORY = 400;      // frames of input history kept (needed for resync)
  const HASH_EVERY = 120;   // desync check period, in frames (2 s)
  const BAD_HASHES_BEFORE_ALARM = 2;

  class Lockstep {
    /**
     * @param {object} o
     * @param {number} o.players     total seats
     * @param {number[]} o.owned     seats this device publishes presses for
     * @param {boolean} o.isHost
     * @param {number} [o.delay=4]   input delay in frames
     * @param {object} o.engine      { setKeys(seat,mask), run(), hashVideo() -> uint32, saveStates(), loadStates(arr) }
     * @param {function} o.send      (msg) => void   guest: to host; host: to every sim guest
     * @param {function} [o.relay]   host only: (msg, exceptPeerId) => void
     * @param {function} [o.onDesync] (info) => void   (host only)
     */
    constructor(o) {
      this.players = o.players;
      this.owned = new Set(o.owned);
      this.isHost = !!o.isHost;
      this.delay = Math.max(1, o.delay || 4);
      this.engine = o.engine;
      this.send = o.send;
      this.relay = o.relay || (() => {});
      this.onDesync = o.onDesync || (() => {});
      this.frame = 0;                 // next frame to simulate
      this.inputs = new Map();        // frame -> Array(players) of masks (undefined = unknown)
      this.latest = new Array(this.players).fill(0); // current held buttons per owned seat
      this.pub = this.delay;          // next frame to publish
      this.stalled = 0;               // consecutive failed ticks (for UI)
      this.totalStalls = 0;
      this.hashes = new Map();        // frame -> { own, peers: Map(peerId -> hash) }
      this.badHashes = 0;
      this.synced = true;
      this.minFrameForHash = 0;
      // Frames before `delay` have no presses by definition: everybody agrees on zeros.
      for (let f = 0; f < this.delay; f++) this.inputs.set(f, new Array(this.players).fill(0));
    }

    setLocalKeys(seat, mask) {
      if (this.owned.has(seat)) this.latest[seat] = mask >>> 0;
    }

    addOwned(seat) { this.owned.add(seat); }
    removeOwned(seat) { this.owned.delete(seat); this.latest[seat] = 0; }

    /** Host only: a player left. Take over their seat (idle buttons) and fill every
     *  already-scheduled frame they never delivered, so nobody stalls forever. */
    takeOver(seat) {
      if (!this.isHost) return;
      this.owned.add(seat);
      this.latest[seat] = 0;
      for (let f = this.frame; f < this.pub; f++) {
        const slot = this._slot(f);
        if (slot[seat] === undefined) {
          slot[seat] = 0;
          this.send({ t: 'in', f, m: { [seat]: 0 } });
        }
      }
    }

    _slot(f) {
      let a = this.inputs.get(f);
      if (!a) { a = new Array(this.players).fill(undefined); this.inputs.set(f, a); }
      return a;
    }

    _publish(f) {
      const m = {};
      const slot = this._slot(f);
      for (const s of this.owned) { m[s] = this.latest[s] >>> 0; slot[s] = m[s]; }
      this.send({ t: 'in', f, m });
    }

    /** Network message from a peer (peerId only meaningful on the host). */
    receive(msg, peerId) {
      if (!msg) return;
      if (msg.t === 'in') {
        if (msg.f < this.frame - HISTORY) return;
        const slot = this._slot(msg.f);
        for (const k of Object.keys(msg.m)) {
          const s = Number(k);
          if (this.owned.has(s)) continue; // never accept presses for seats we own
          slot[s] = msg.m[k] >>> 0;
        }
        if (this.isHost) this.relay(msg, peerId);
      } else if (msg.t === 'h') {
        if (!this.isHost) return;
        const rec = this.hashes.get(msg.f) || { own: undefined, peers: new Map() };
        rec.peers.set(peerId, msg.h >>> 0);
        this.hashes.set(msg.f, rec);
        this._compare(msg.f);
      }
    }

    /** Try to simulate one frame. Returns true if the simulation advanced. */
    tick() {
      while (this.pub <= this.frame + this.delay) this._publish(this.pub++);
      const arr = this.inputs.get(this.frame);
      if (!arr) { this.stalled++; this.totalStalls++; return false; }
      for (let s = 0; s < this.players; s++) if (arr[s] === undefined) { this.stalled++; this.totalStalls++; return false; }
      this.stalled = 0;
      for (let s = 0; s < this.players; s++) this.engine.setKeys(s, arr[s]);
      this.engine.run();
      const f = this.frame++;
      if (f >= HISTORY) this.inputs.delete(f - HISTORY);
      if (f % HASH_EVERY === 0 && f >= this.minFrameForHash) this._hashPoint(f);
      return true;
    }

    _hashPoint(f) {
      const h = this.engine.hashVideo() >>> 0;
      if (this.isHost) {
        const rec = this.hashes.get(f) || { own: undefined, peers: new Map() };
        rec.own = h;
        this.hashes.set(f, rec);
        this._compare(f);
        for (const old of this.hashes.keys()) if (old < f - HASH_EVERY * 5) this.hashes.delete(old);
      } else {
        this.send({ t: 'h', f, h });
      }
    }

    _compare(f) {
      const rec = this.hashes.get(f);
      if (!rec || rec.own === undefined) return;
      const bad = [];
      for (const [pid, h] of rec.peers) if (h !== rec.own) bad.push(pid);
      if (bad.length) {
        this.badHashes++;
        this.synced = false;
        if (this.badHashes >= BAD_HASHES_BEFORE_ALARM) this.onDesync({ frame: f, peers: bad });
      } else if (rec.peers.size) {
        this.badHashes = 0;
        this.synced = true;
      }
      rec.peers.clear();
    }

    /** Host: capture a state and return {f, states} to send to every sim guest. */
    makeSnapshot() {
      const states = this.engine.saveStates();
      // The host also reloads the very state it sends, so every device resumes
      // from byte-identical conditions (including link-driver bookkeeping).
      this.engine.loadStates(states);
      this.minFrameForHash = this.frame + 1;
      this.badHashes = 0; this.synced = true;
      this.hashes.clear();
      return { f: this.frame, states };
    }

    /** Guest: adopt the host's state at frame f. */
    applySnapshot(snap) {
      this.engine.loadStates(snap.states);
      this.frame = snap.f;
      // `pub` only ever grows, so nothing is published twice; if this device was
      // behind the host, the normal publish loop in tick() fills in the missing
      // frames up to f + delay.
      this.minFrameForHash = this.frame + 1;
      this.stalled = 0;
    }
  }

  const api = { Lockstep, HISTORY, HASH_EVERY };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.MgsLockstep = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
