/* Touchscreen controls overlay (GBA-style pad for phones and tablets).
 *
 * Why: a guest opening a magic link on their phone has no keyboard or
 * gamepad — without this they can watch but never play. The overlay is a
 * transparent layer with a D-pad, A/B, L/R shoulders, START/SELECT, and a
 * small pause button; it feeds the SAME per-player key-mask pipeline the
 * keyboard and gamepads use (main.js merges `mgbaTouch.maskFor(p)` into
 * sendKeys), so host/local play and guest input forwarding both work
 * unchanged.
 *
 * Multi-touch: every pointer is tracked independently (press A while holding
 * a direction), and the D-pad supports sliding between directions without
 * lifting the thumb — the natural way people play GBA games.
 *
 * Visibility modes (persisted): 'auto' (default) shows on the first real
 * touch and when a magic-link guest connects; 'on'/'off' force it. Desktops
 * never see it in auto mode.
 */
(() => {
  // Must match GBA_BUTTONS in main.js (mGBA's key mask layout).
  const BUTTON_BITS = {
    A: 1 << 0, B: 1 << 1, SELECT: 1 << 2, START: 1 << 3,
    RIGHT: 1 << 4, LEFT: 1 << 5, UP: 1 << 6, DOWN: 1 << 7,
    R: 1 << 8, L: 1 << 9,
  };

  const MODE_KEY = 'mgba-splitscreen_touch_v1';
  const MAX_PLAYERS = 4;

  const state = {
    root: null,
    note: null,
    picker: null,
    callbacks: {},
    masks: new Array(MAX_PLAYERS).fill(0),
    activePlayer: 0,
    playerCount: 2,
    pointers: new Map(), // pointerId -> button name currently held
    mode: 'auto',        // 'auto' | 'on' | 'off'
    touchSeen: false,    // a real touch input happened at least once
    guestSeat: null,     // set when the magic-link guest is welcomed
    awaitingGuest: false, // ?online=join seen but welcome not yet received
  };

  function loadMode() {
    try {
      const raw = localStorage.getItem(MODE_KEY);
      if (raw === 'on' || raw === 'off' || raw === 'auto') state.mode = raw;
    } catch (_) {}
  }

  function saveMode() {
    try { localStorage.setItem(MODE_KEY, state.mode); } catch (_) {}
  }

  function query(name) {
    try { return new URLSearchParams(window.location.search).get(name); } catch (_) { return null; }
  }

  function shouldShow() {
    if (state.editing) return true;
    if (state.mode === 'on') return true;
    if (state.mode === 'off') return false;
    return state.touchSeen || state.guestSeat !== null
      || (state.awaitingGuest && state.touchSeen);
  }

  function updateVisibility() {
    if (!state.root) return;
    state.root.hidden = !shouldShow();
  }

  function updatePicker() {
    if (!state.picker) return;
    if (state.guestSeat !== null) {
      // Guests drive exactly one seat; the picker is meaningless to them.
      state.picker.hidden = true;
      if (state.note) state.note.textContent = `You are Player ${state.guestSeat + 1}`;
      return;
    }
    state.picker.hidden = state.playerCount <= 1;
    state.picker.querySelectorAll('button').forEach((btn) => {
      const p = parseInt(btn.dataset.player, 10);
      btn.classList.toggle('active', p === state.activePlayer);
      btn.style.display = p < state.playerCount ? '' : 'none';
    });
    if (state.note) state.note.textContent = '';
  }

  function sendMask() {
    // Route through main.js's union sender so keyboard/gamepad masks survive.
    state.callbacks.onInput?.(state.activePlayer);
  }

  function pressedVisual(btn, on) {
    const el = state.root && state.root.querySelector(`[data-btn="${btn}"]`);
    if (el) el.classList.toggle('pressed', on);
  }

  function press(btn) {
    const bit = BUTTON_BITS[btn];
    if (!bit || (state.masks[state.activePlayer] & bit)) return;
    // Guests must not inject input before the host assigns their seat —
    // seat 0 is Player 1 on the host, and an unassigned guest is nobody.
    if (state.awaitingGuest && state.guestSeat === null) return;
    state.masks[state.activePlayer] |= bit;
    pressedVisual(btn, true);
    try { navigator.vibrate && navigator.vibrate(8); } catch (_) {}
    sendMask();
  }

  function release(btn) {
    const bit = BUTTON_BITS[btn];
    if (!bit || !(state.masks[state.activePlayer] & bit)) { pressedVisual(btn, false); return; }
    state.masks[state.activePlayer] &= ~bit;
    pressedVisual(btn, false);
    sendMask();
  }

  function buttonAt(x, y) {
    const el = document.elementFromPoint(x, y);
    return el && el.closest ? el.closest('[data-btn]') : null;
  }

  function onPointerDown(e) {
    if (!state.root || state.root.hidden || state.editing) return;
    const target = e.target.closest ? e.target.closest('[data-btn]') : null;
    if (!target) return;
    e.preventDefault();
    try { state.root.setPointerCapture(e.pointerId); } catch (_) {}
    state.pointers.set(e.pointerId, target.dataset.btn);
    press(target.dataset.btn);
  }

  function onPointerMove(e) {
    if (state.editing || !state.pointers.has(e.pointerId)) return;
    e.preventDefault();
    const hit = buttonAt(e.clientX, e.clientY);
    const btn = hit ? hit.dataset.btn : null;
    const current = state.pointers.get(e.pointerId);
    if (btn === current) return;
    // Slide support: release the old button, press the new one under the
    // finger (D-pad rolls between directions; lifting off releases all).
    if (current) release(current);
    if (btn) press(btn);
    state.pointers.set(e.pointerId, btn);
  }

  function onPointerUp(e) {
    if (!state.pointers.has(e.pointerId)) return;
    e.preventDefault();
    const btn = state.pointers.get(e.pointerId);
    state.pointers.delete(e.pointerId);
    if (btn) release(btn);
  }

  function bindEvents() {
    state.root.addEventListener('pointerdown', onPointerDown);
    state.root.addEventListener('pointermove', onPointerMove);
    state.root.addEventListener('pointerup', onPointerUp);
    state.root.addEventListener('pointercancel', onPointerUp);
    // A long-press must never open the text-selection/callout UI mid-game.
    state.root.addEventListener('contextmenu', (e) => e.preventDefault());
    // Pause button (tiny, top-center): same hotkey path as the menubar.
    const pauseBtn = state.root.querySelector('[data-action="pause"]');
    if (pauseBtn) {
      pauseBtn.addEventListener('pointerdown', (e) => e.preventDefault());
      pauseBtn.addEventListener('click', () => state.callbacks.onPause?.());
    }
    if (state.picker) {
      state.picker.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-player]');
        if (!btn) return;
        const p = parseInt(btn.dataset.player, 10);
        if (p >= 0 && p < state.playerCount && p !== state.activePlayer) {
          // Don't let a held button stick on the old player.
          for (const [id, b] of state.pointers) { if (b) release(b); }
          state.masks.fill(0);
          state.activePlayer = p;
          updatePicker();
          sendMask();
        }
      });
    }
    // Auto-show on the first REAL touch (desktop mice never trigger this).
    window.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'touch' || e.pointerType === 'pen') {
        if (!state.touchSeen) {
          state.touchSeen = true;
          updateVisibility();
        }
      }
    }, { capture: true, passive: true });
  }

  function setModeLabel() {
    const btn = document.getElementById('toggle-touch');
    if (btn) {
      const label = state.mode === 'auto' ? 'Auto' : state.mode === 'on' ? 'On' : 'Off';
      btn.textContent = `Touch Controls: ${label}`;
      btn.classList.toggle('active', state.mode !== 'off');
    }
  }


  // ---- Layout editor: move / resize button groups, opacity (saved per orientation) ----
  const LAYOUT_KEY = 'mgs_touch_layout_v2';
  const GROUPS = ['L', 'R', 'dpad', 'A', 'B', 'meta', 'pause'];
  const tt = (k) => (window.MgsI18n ? window.MgsI18n.t(k) : k);
  const ed = { layout: null, panel: null, selected: null, drag: null };

  function orient() { return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait'; }
  function loadLayout() {
    try { ed.layout = JSON.parse(localStorage.getItem(LAYOUT_KEY)) || {}; } catch (_) { ed.layout = {}; }
    ed.layout.opacity = ed.layout.opacity || 0.85;
    ed.layout.global = ed.layout.global || 1;
  }
  function saveLayout() { try { localStorage.setItem(LAYOUT_KEY, JSON.stringify(ed.layout)); } catch (_) {} }
  function groupEl(g) { return state.root && state.root.querySelector(`[data-group="${g}"]`); }
  function tagGroups() {
    const r = state.root; if (!r) return;
    const set = (el, g) => { if (el) el.dataset.group = g; };
    set(r.querySelector('[data-btn="L"]'), 'L'); set(r.querySelector('[data-btn="R"]'), 'R');
    set(r.querySelector('.touch-dpad'), 'dpad'); set(r.querySelector('.face-a'), 'A'); set(r.querySelector('.face-b'), 'B');
    set(r.querySelector('.touch-center-row'), 'meta'); set(r.querySelector('.touch-top-center'), 'pause');
  }
  function applyLayout() {
    const r = state.root; if (!r || !ed.layout) return;
    r.style.opacity = String(ed.layout.opacity);
    const set = ed.layout[orient()];
    r.classList.toggle('custom', !!set);
    GROUPS.forEach((g) => {
      const el = groupEl(g); if (!el) return;
      const v = set && set[g];
      if (!v) { el.style.left = el.style.top = el.style.transform = ''; return; }
      el.style.left = (v.x * 100) + '%'; el.style.top = (v.y * 100) + '%';
      el.style.transform = `translate(-50%,-50%) scale(${(v.s || 1) * ed.layout.global})`;
    });
  }
  function snapshotDefaults() {
    // Turn the current (flow) layout into explicit positions, so editing starts where things are now.
    const r = state.root; const wasCustom = r.classList.contains('custom');
    if (wasCustom) return;
    const set = {};
    GROUPS.forEach((g) => {
      const el = groupEl(g); if (!el) return;
      const b = el.getBoundingClientRect();
      set[g] = { x: (b.left + b.width / 2) / window.innerWidth, y: (b.top + b.height / 2) / window.innerHeight, s: 1 };
    });
    ed.layout[orient()] = set;
  }
  function select(g) {
    ed.selected = g;
    state.root.querySelectorAll('[data-group]').forEach((el) => el.classList.toggle('sel', el.dataset.group === g));
    const sl = ed.panel && ed.panel.querySelector('#te-sel');
    if (sl) { const v = (ed.layout[orient()] || {})[g]; sl.disabled = !v; sl.value = v ? v.s : 1; }
  }
  function buildPanel() {
    const p = document.createElement('div');
    p.id = 'touch-edit-panel';
    p.innerHTML = `<div class="te-hint"></div>
      <label><span data-k="te_all"></span><input type="range" id="te-all" min="0.6" max="1.8" step="0.05"></label>
      <label><span data-k="te_sel"></span><input type="range" id="te-sel" min="0.5" max="2.5" step="0.05"></label>
      <label><span data-k="te_op"></span><input type="range" id="te-op" min="0.25" max="1" step="0.05"></label>
      <div class="te-row"><button type="button" id="te-reset"></button><button type="button" id="te-done" class="main"></button></div>`;
    document.body.appendChild(p);
    const L = () => {
      p.querySelector('.te-hint').textContent = tt('te_hint');
      p.querySelectorAll('[data-k]').forEach((e) => { e.textContent = tt(e.dataset.k); });
      p.querySelector('#te-reset').textContent = tt('te_reset'); p.querySelector('#te-done').textContent = tt('te_done');
    };
    L(); document.addEventListener('mgs-lang', L);
    p.querySelector('#te-all').oninput = (e) => { ed.layout.global = Number(e.target.value); applyLayout(); saveLayout(); };
    p.querySelector('#te-op').oninput = (e) => { ed.layout.opacity = Number(e.target.value); applyLayout(); saveLayout(); };
    p.querySelector('#te-sel').oninput = (e) => {
      const v = (ed.layout[orient()] || {})[ed.selected]; if (!v) return;
      v.s = Number(e.target.value); applyLayout(); saveLayout();
    };
    p.querySelector('#te-reset').onclick = () => {
      delete ed.layout[orient()]; ed.layout.global = 1; ed.layout.opacity = 0.85; saveLayout();
      state.root.classList.remove('custom'); applyLayout(); snapshotDefaults(); applyLayout();
      p.querySelector('#te-all').value = 1; p.querySelector('#te-op').value = 0.85; select(ed.selected);
    };
    p.querySelector('#te-done').onclick = () => api.stopEdit();
    ed.panel = p;
  }
  function onEditDown(e) {
    if (!state.editing) return;
    const el = e.target.closest && e.target.closest('[data-group]'); if (!el) return;
    e.preventDefault();
    const g = el.dataset.group; select(g);
    const v = (ed.layout[orient()] || {})[g]; if (!v) return;
    try { state.root.setPointerCapture(e.pointerId); } catch (_) {}
    ed.drag = { id: e.pointerId, g, dx: e.clientX / window.innerWidth - v.x, dy: e.clientY / window.innerHeight - v.y };
  }
  function onEditMove(e) {
    if (!state.editing || !ed.drag || ed.drag.id !== e.pointerId) return;
    e.preventDefault();
    const v = ed.layout[orient()][ed.drag.g];
    v.x = Math.max(0.03, Math.min(0.97, e.clientX / window.innerWidth - ed.drag.dx));
    v.y = Math.max(0.03, Math.min(0.97, e.clientY / window.innerHeight - ed.drag.dy));
    applyLayout();
  }
  function onEditUp(e) { if (ed.drag && ed.drag.id === e.pointerId) { ed.drag = null; saveLayout(); } }

  const api = {
    startEdit() {
      if (!state.root) return;
      for (const [, b] of state.pointers) { if (b) release(b); }
      state.pointers.clear(); state.masks.fill(0);
      state.root.hidden = false;           // show even on desktop while editing
      state.editing = true;
      state.root.classList.add('editing');
      snapshotDefaults(); applyLayout();
      if (!ed.panel) buildPanel();
      ed.panel.hidden = false;
      ed.panel.querySelector('#te-all').value = ed.layout.global;
      ed.panel.querySelector('#te-op').value = ed.layout.opacity;
      select(ed.selected || 'dpad');
    },
    stopEdit() {
      state.editing = false; ed.drag = null;
      if (state.root) state.root.classList.remove('editing');
      state.root && state.root.querySelectorAll('[data-group]').forEach((el) => el.classList.remove('sel'));
      if (ed.panel) ed.panel.hidden = true;
      saveLayout(); updateVisibility();
    },
    isEditing: () => !!state.editing,
    initLayout() {
      loadLayout(); tagGroups(); applyLayout();
      state.root.addEventListener('pointerdown', onEditDown);
      state.root.addEventListener('pointermove', onEditMove);
      state.root.addEventListener('pointerup', onEditUp);
      state.root.addEventListener('pointercancel', onEditUp);
      window.addEventListener('resize', () => { if (!state.editing) applyLayout(); });
    },
  };

  window.mgbaTouch = {
    startEdit: api.startEdit, stopEdit: api.stopEdit, isEditing: api.isEditing,
    init(callbacks) {
      state.callbacks = callbacks || {};
      state.root = document.getElementById('touch-controls');
      state.note = document.getElementById('touch-note');
      state.picker = document.getElementById('touch-player-picker');
      if (!state.root) return;
      loadMode();
      state.awaitingGuest = query('online') === 'join';
      // Build the P1-P4 picker once (local play only; guests never see it).
      if (state.picker && !state.picker.children.length) {
        for (let p = 0; p < MAX_PLAYERS; p++) {
          const b = document.createElement('button');
          b.type = 'button';
          b.dataset.player = String(p);
          b.textContent = `P${p + 1}`;
          state.picker.appendChild(b);
        }
      }
      bindEvents();
      api.initLayout();
      setModeLabel();
      updatePicker();
      updateVisibility();
    },
    // main.js calls this when the player count changes (screens rebuilt).
    setPlayerCount(count) {
      const n = Math.max(1, Math.min(MAX_PLAYERS, count | 0));
      if (n === state.playerCount) return;
      state.playerCount = n;
      state.masks.fill(0);
      // Never clamp an assigned guest down to the local count: guests build a
      // 1-screen view but drive a seat the host picked (0..3). Only local
      // players follow the local grid size.
      if (state.guestSeat === null) {
        state.activePlayer = Math.min(state.activePlayer, n - 1);
      }
      updatePicker();
    },
    // main.js calls this when an online session role resolves:
    // seat = 0-based guest slot, or null for hosts/local play.
    setGuest(seat) {
      state.guestSeat = (Number.isInteger(seat) && seat >= 0) ? seat : null;
      if (state.guestSeat !== null) {
        state.activePlayer = state.guestSeat;
        state.masks.fill(0);
      }
      updatePicker();
      updateVisibility(); // magic-link arrival (or host fallback) re-evaluates
    },
    cycleMode() {
      state.mode = state.mode === 'auto' ? 'on' : state.mode === 'on' ? 'off' : 'auto';
      saveMode();
      setModeLabel();
      updateVisibility();
      state.callbacks.onStatus?.(
        state.mode === 'auto' ? 'Touch controls: auto (shows on touch devices and guests)'
          : state.mode === 'on' ? 'Touch controls: always shown'
          : 'Touch controls: hidden');
    },
    maskFor(player) {
      return state.masks[player] || 0;
    },
    releaseAll() {
      state.masks.fill(0);
      state.pointers.clear();
      if (!state.root) return;
      state.root.querySelectorAll('.touch-btn.pressed').forEach((el) => el.classList.remove('pressed'));
    },
  };
})();
