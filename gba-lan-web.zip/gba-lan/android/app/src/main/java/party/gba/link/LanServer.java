package party.gba.link;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tiny LAN server that lets a phone HOST a room: no Node, no libraries.
 *  - serves the web app (so friends can also join from a browser),
 *  - speaks the PeerJS signalling protocol (WebSocket) the page already uses.
 * Plain java.net only, so it also runs (and is tested) on a desktop JVM.
 */
public class LanServer {
  public interface Source { InputStream open(String path) throws IOException; }

  private final Source source;
  private ServerSocket server;
  private volatile boolean running;
  private int port;
  private final Map<String, Peer> peers = new ConcurrentHashMap<>();
  private final Random rnd = new Random();

  public LanServer(Source source) { this.source = source; }

  public synchronized int start(int preferred) throws IOException {
    if (running) return port;
    IOException last = null;
    for (int p = preferred; p < preferred + 20; p++) {
      try { server = new ServerSocket(p, 50); port = p; last = null; break; } catch (IOException e) { last = e; }
    }
    if (last != null) throw last;
    running = true;
    Thread t = new Thread(() -> {
      while (running) {
        try {
          final Socket s = server.accept();
          s.setTcpNoDelay(true);
          Thread c = new Thread(() -> handle(s), "lan-conn");
          c.setDaemon(true);
          c.start();
        } catch (IOException e) { if (running) { try { Thread.sleep(50); } catch (InterruptedException ignored) {} } }
      }
    }, "lan-accept");
    t.setDaemon(true);
    t.start();
    return port;
  }

  public synchronized void stop() {
    running = false;
    try { if (server != null) server.close(); } catch (IOException ignored) {}
    for (Peer p : peers.values()) p.close();
    peers.clear();
  }

  public int port() { return port; }

  public static List<String> ips() {
    List<String> out = new ArrayList<>();
    try {
      for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
        if (!ni.isUp() || ni.isLoopback()) continue;
        Enumeration<InetAddress> en = ni.getInetAddresses();
        while (en.hasMoreElements()) {
          InetAddress a = en.nextElement();
          if (a instanceof Inet4Address && !a.isLoopbackAddress()) out.add(a.getHostAddress());
        }
      }
    } catch (Exception ignored) {}
    return out;
  }

  public String infoJson() {
    StringBuilder sb = new StringBuilder("{\"port\":").append(port).append(",\"ips\":[");
    List<String> l = ips();
    for (int i = 0; i < l.size(); i++) { if (i > 0) sb.append(','); sb.append('"').append(l.get(i)).append('"'); }
    return sb.append("]}").toString();
  }

  // ---------------------------------------------------------------- HTTP
  private static String readLine(InputStream in) throws IOException {
    ByteArrayOutputStream b = new ByteArrayOutputStream();
    int c;
    while ((c = in.read()) != -1) {
      if (c == '\n') break;
      if (c != '\r') b.write(c);
      if (b.size() > 16384) throw new IOException("line too long");
    }
    if (c == -1 && b.size() == 0) return null;
    return b.toString("ISO-8859-1");
  }

  private void handle(Socket s) {
    try {
      s.setSoTimeout(15000);
      InputStream in = new BufferedInputStream(s.getInputStream());
      OutputStream out = s.getOutputStream();
      String line = readLine(in);
      if (line == null || line.isEmpty()) { s.close(); return; }
      String[] rl = line.split(" ");
      if (rl.length < 2) { s.close(); return; }
      String method = rl[0].toUpperCase(Locale.ROOT), target = rl[1];
      Map<String, String> h = new HashMap<>();
      String hl;
      while ((hl = readLine(in)) != null && !hl.isEmpty()) {
        int i = hl.indexOf(':');
        if (i > 0) h.put(hl.substring(0, i).trim().toLowerCase(Locale.ROOT), hl.substring(i + 1).trim());
      }
      String path = target, query = "";
      int q = target.indexOf('?');
      if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }

      if ("websocket".equalsIgnoreCase(h.get("upgrade")) && path.startsWith("/peerjs")) {
        s.setSoTimeout(0);
        websocket(s, in, out, h, query);
        return;
      }
      int len = 0;
      try { len = Integer.parseInt((h.containsKey("content-length") ? h.get("content-length") : "0")); } catch (NumberFormatException ignored) {}
      for (int i = 0; i < len && in.read() != -1; i++) { /* drain body */ }
      route(method, path, out);
      out.flush();
      s.close();
    } catch (Exception e) {
      try { s.close(); } catch (IOException ignored) {}
    }
  }

  private static void head(OutputStream out, int code, String type) throws IOException {
    String msg = code == 200 ? "OK" : code == 204 ? "No Content" : code == 404 ? "Not Found" : "Error";
    String hd = "HTTP/1.1 " + code + " " + msg + "\r\n"
        + "Content-Type: " + type + "\r\n"
        + "Access-Control-Allow-Origin: *\r\n"
        + "Access-Control-Allow-Headers: *\r\n"
        + "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        + "Cache-Control: no-cache\r\n"
        + "Connection: close\r\n\r\n";
    out.write(hd.getBytes(StandardCharsets.ISO_8859_1));
  }

  private static void text(OutputStream out, int code, String type, String body) throws IOException {
    head(out, code, type);
    out.write(body.getBytes(StandardCharsets.UTF_8));
  }

  private static String mime(String p) {
    String l = p.toLowerCase(Locale.ROOT);
    if (l.endsWith(".html")) return "text/html; charset=utf-8";
    if (l.endsWith(".js")) return "text/javascript; charset=utf-8";
    if (l.endsWith(".css")) return "text/css; charset=utf-8";
    if (l.endsWith(".wasm")) return "application/wasm";
    if (l.endsWith(".json") || l.endsWith(".webmanifest")) return "application/json";
    if (l.endsWith(".png")) return "image/png";
    if (l.endsWith(".svg")) return "image/svg+xml";
    if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
    if (l.endsWith(".ico")) return "image/x-icon";
    return "application/octet-stream";
  }

  private void route(String method, String path, OutputStream out) throws IOException {
    if ("OPTIONS".equals(method)) { head(out, 204, "text/plain"); return; }
    if (path.startsWith("/peerjs")) {
      String rest = path.substring("/peerjs".length());
      if (rest.endsWith("/")) rest = rest.substring(0, rest.length() - 1);
      if (rest.equals("/peerjs/peers") || rest.equals("/peers")) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (String id : peers.keySet()) { if (!first) sb.append(','); first = false; sb.append('"').append(id).append('"'); }
        text(out, 200, "application/json", sb.append(']').toString());
      } else if (rest.equals("/peerjs/id") || rest.equals("/id")) {
        text(out, 200, "text/html", randomId());
      } else {
        text(out, 200, "application/json", "{\"name\":\"PeerJS Server\",\"description\":\"A server side element to broker connections between PeerJS clients.\",\"website\":\"https://peerjs.com/\"}");
      }
      return;
    }
    if (path.equals("/info")) { text(out, 200, "application/json", infoJson()); return; }
    if (path.equals("/session_log")) { head(out, 204, "text/plain"); return; }
    if (path.equals("/")) path = "/index.html";
    if (path.contains("..")) { text(out, 404, "text/plain", "not found"); return; }
    InputStream f;
    try { f = source.open(path.substring(1)); } catch (IOException e) { f = null; }
    if (f == null) { text(out, 404, "text/plain", "not found"); return; }
    head(out, 200, mime(path));
    byte[] buf = new byte[32768];
    int n;
    try { while ((n = f.read(buf)) > 0) out.write(buf, 0, n); } finally { f.close(); }
  }

  private String randomId() {
    String a = "abcdefghijklmnopqrstuvwxyz0123456789";
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 12; i++) sb.append(a.charAt(rnd.nextInt(a.length())));
    return sb.toString();
  }

  // ----------------------------------------------------- PeerJS signalling
  private static String param(String query, String key) {
    for (String kv : query.split("&")) {
      int i = kv.indexOf('=');
      if (i > 0 && kv.substring(0, i).equals(key)) {
        try { return java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8"); } catch (Exception e) { return kv.substring(i + 1); }
      }
    }
    return null;
  }

  private class Peer {
    final String id; final Socket socket; final OutputStream out;
    Peer(String id, Socket s, OutputStream o) { this.id = id; this.socket = s; this.out = o; }
    synchronized void send(String json) {
      try {
        byte[] p = json.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream f = new ByteArrayOutputStream();
        f.write(0x81);
        if (p.length < 126) f.write(p.length);
        else if (p.length < 65536) { f.write(126); f.write(p.length >> 8); f.write(p.length & 255); }
        else { f.write(127); for (int i = 7; i >= 0; i--) f.write((int) (((long) p.length >> (8 * i)) & 255)); }
        f.write(p);
        out.write(f.toByteArray());
        out.flush();
      } catch (IOException e) { close(); }
    }
    synchronized void raw(int op, byte[] payload) {
      try { out.write(0x80 | op); out.write(payload.length); out.write(payload); out.flush(); } catch (IOException e) { close(); }
    }
    void close() { try { socket.close(); } catch (IOException ignored) {} }
  }

  private void websocket(Socket s, InputStream in, OutputStream out, Map<String, String> h, String query) throws Exception {
    String key = h.get("sec-websocket-key");
    if (key == null) { s.close(); return; }
    String accept = b64(MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.ISO_8859_1)));
    out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));
    out.flush();

    String id = param(query, "id");
    Peer me = new Peer(id == null ? "" : id, s, out);
    if (id == null || id.isEmpty()) { me.send("{\"type\":\"ERROR\",\"payload\":{\"msg\":\"No id provided.\"}}"); s.close(); return; }
    Peer old = peers.get(id);
    if (old != null && !old.socket.isClosed()) {
      me.send("{\"type\":\"ID-TAKEN\",\"payload\":{\"msg\":\"ID is taken\"}}");
      s.close();
      return;
    }
    peers.put(id, me);
    me.send("{\"type\":\"OPEN\"}");
    try {
      while (running && !s.isClosed()) {
        int b0 = in.read(); if (b0 < 0) break;
        int b1 = in.read(); if (b1 < 0) break;
        int op = b0 & 15;
        boolean masked = (b1 & 128) != 0;
        long len = b1 & 127;
        if (len == 126) len = ((in.read() & 255) << 8) | (in.read() & 255);
        else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | (in.read() & 255); }
        if (len > 8 * 1024 * 1024) break;
        byte[] mask = new byte[4];
        if (masked) readFully(in, mask);
        byte[] data = new byte[(int) len];
        readFully(in, data);
        if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
        if (op == 8) break;
        if (op == 9) { me.raw(10, data); continue; }
        if (op != 1) continue;
        onMessage(me, new String(data, StandardCharsets.UTF_8));
      }
    } catch (IOException ignored) {
    } finally {
      peers.remove(id, me);
      me.close();
    }
  }

  private static String b64(byte[] d) {
    String a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < d.length; i += 3) {
      int v = (d[i] & 255) << 16 | (i + 1 < d.length ? (d[i + 1] & 255) << 8 : 0) | (i + 2 < d.length ? d[i + 2] & 255 : 0);
      sb.append(a.charAt(v >> 18 & 63)).append(a.charAt(v >> 12 & 63));
      sb.append(i + 1 < d.length ? a.charAt(v >> 6 & 63) : '=').append(i + 2 < d.length ? a.charAt(v & 63) : '=');
    }
    return sb.toString();
  }

  private static void readFully(InputStream in, byte[] b) throws IOException {
    int o = 0;
    while (o < b.length) { int n = in.read(b, o, b.length - o); if (n < 0) throw new IOException("eof"); o += n; }
  }

  // The PeerJS messages we relay are flat JSON: {"type":..,"dst":..,"payload":{..}}.
  // Parse type/dst without a JSON library, then re-emit with "src" added.
  private void onMessage(Peer me, String msg) {
    String type = jsonString(msg, "type");
    if (type == null || "HEARTBEAT".equals(type)) return;
    String dst = jsonString(msg, "dst");
    if (dst == null) return;
    if (!(type.equals("OFFER") || type.equals("ANSWER") || type.equals("CANDIDATE") || type.equals("LEAVE") || type.equals("EXPIRE"))) return;
    int pi = msg.indexOf("\"payload\"");
    String payload = null;
    if (pi >= 0) {
      int c = msg.indexOf(':', pi);
      int end = msg.lastIndexOf('}');
      if (c > 0 && end > c) payload = msg.substring(c + 1, end).trim();
    }
    Peer to = peers.get(dst);
    if (to == null) {
      if (!type.equals("LEAVE") && !type.equals("EXPIRE")) me.send("{\"type\":\"EXPIRE\",\"src\":\"" + esc(dst) + "\"}");
      return;
    }
    StringBuilder sb = new StringBuilder("{\"type\":\"").append(type).append("\",\"src\":\"").append(esc(me.id)).append("\",\"dst\":\"").append(esc(dst)).append('"');
    if (payload != null) sb.append(",\"payload\":").append(payload);
    sb.append('}');
    to.send(sb.toString());
  }

  private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

  /** Value of a top-level-ish string field ("key":"value"); fine for PeerJS envelopes. */
  private static String jsonString(String json, String key) {
    int depth = 0;
    String needle = "\"" + key + "\"";
    int from = 0;
    while (true) {
      int i = json.indexOf(needle, from);
      if (i < 0) return null;
      // only accept occurrences at brace depth 1 (the envelope, not inside payload)
      depth = 0;
      boolean inStr = false;
      for (int k = 0; k < i; k++) {
        char ch = json.charAt(k);
        if (inStr) { if (ch == '\\') k++; else if (ch == '"') inStr = false; }
        else if (ch == '"') inStr = true;
        else if (ch == '{' || ch == '[') depth++;
        else if (ch == '}' || ch == ']') depth--;
      }
      if (depth == 1) {
        int c = json.indexOf(':', i + needle.length());
        int a = json.indexOf('"', c + 1);
        if (c < 0 || a < 0) return null;
        StringBuilder sb = new StringBuilder();
        for (int k = a + 1; k < json.length(); k++) {
          char ch = json.charAt(k);
          if (ch == '\\' && k + 1 < json.length()) { sb.append(json.charAt(++k)); continue; }
          if (ch == '"') break;
          sb.append(ch);
        }
        return sb.toString();
      }
      from = i + needle.length();
    }
  }
}
