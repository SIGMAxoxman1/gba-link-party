package party.gba.link;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends BridgeActivity {
  private volatile boolean immersive = false;
  private LanServer lan;

  /** Exposed to the page as window.MgsNative. */
  public class NativeBridge {
    /** Starts (once) the phone's own room server and returns {"port":N,"ips":[...]}. */
    @JavascriptInterface
    public synchronized String startServer() {
      try {
        if (lan == null) {
          lan = new LanServer(new LanServer.Source() {
            @Override public InputStream open(String path) throws IOException {
              try { return getAssets().open("public/" + path); } catch (IOException e) { return null; }
            }
          });
        }
        lan.start(8090);
        return lan.infoJson();
      } catch (Exception e) {
        return "{\"error\":\"" + String.valueOf(e.getMessage()).replace("\"", "'") + "\"}";
      }
    }

    /** Hide the system bars only while a game is running (immersive mode closes the soft keyboard). */
    @JavascriptInterface
    public void immersive(final boolean on) {
      immersive = on;
      runOnUiThread(new Runnable() { @Override public void run() { applySystemUi(); } });
    }
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Keep the screen on while playing (a sleeping phone is dropped from the room).
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    // Capacitor may already have started loading the page; a reload makes sure the
    // interface exists before the page's scripts run.
    getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "MgsNative");
    getBridge().getWebView().reload();
  }

  private void applySystemUi() {
    View d = getWindow().getDecorView();
    if (immersive) {
      d.setSystemUiVisibility(
          View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    } else {
      d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) applySystemUi();
  }

  @Override
  public void onDestroy() {
    if (lan != null) lan.stop();
    super.onDestroy();
  }
}
