package party.gba.link;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.PatternMatcher;
import android.net.wifi.SoftApConfiguration;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.util.Base64;

public class MainActivity extends BridgeActivity {
  private volatile boolean immersive = false;
  private LanServer lan;
  private final LanServer.Watcher watcher = new LanServer.Watcher();
  private WifiManager.LocalOnlyHotspotReservation hotspot;
  private boolean pendingHotspot = false;
  private ConnectivityManager.NetworkCallback joinCb;
  private static final String GBA_PASS = "0123456789";
  private static final int REQ_HOTSPOT = 7711;

  private void toJs(final String fn, final String json) {
    runOnUiThread(new Runnable() { @Override public void run() {
      try { getBridge().getWebView().evaluateJavascript("window." + fn + " && window." + fn + "(" + json + ")", null); } catch (Exception ignored) {}
    } });
  }


  /** Exposed to the page as window.MgsNative. */
  public class NativeBridge {
    /** Starts (once) the phone's own room server and returns {"port":N,"ips":[...]}. */
    @JavascriptInterface
    public synchronized String startServer() {
      try {
        if (lan == null) {
          lan = new LanServer(new LanServer.Source() {
            @Override public InputStream open(String path) throws IOException {
              try { return getAssets().open("public/" + path); } catch (IOException e) { return null; }
            }
          });
        }
        lan.start(8090);
        return lan.infoJson();
      } catch (Exception e) {
        return "{\"error\":\"" + String.valueOf(e.getMessage()).replace("\"", "'") + "\"}";
      }
    }


    // ---- save files: Android/data/party.gba.link/files/GBA Link Party/Saves ----
    private File savesDir() {
      File base = getExternalFilesDir(null);
      if (base == null) base = getFilesDir();
      File d = new File(new File(base, "GBA Link Party"), "Saves");
      if (!d.exists()) d.mkdirs();
      return d;
    }
    private File savesFile(String name) {
      if (name == null || !name.toLowerCase().endsWith(".glpstate") || name.contains("/") || name.contains("\\")) return null;
      return new File(savesDir(), name);
    }
    @JavascriptInterface public String filesDir() { return savesDir().getAbsolutePath(); }
    @JavascriptInterface public String writeFile(String name, String b64) {
      try {
        File f = savesFile(name); if (f == null) return "bad";
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        try { o.write(Base64.decode(b64, Base64.DEFAULT)); } finally { o.close(); }
        if (f.exists()) f.delete();
        return tmp.renameTo(f) ? "ok" : "rename";
      } catch (Exception e) { return "error: " + e.getMessage(); }
    }
    @JavascriptInterface public String readFile(String name) {
      try {
        File f = savesFile(name); if (f == null || !f.exists()) return "";
        byte[] b = new byte[(int) f.length()];
        FileInputStream in = new FileInputStream(f);
        try { int o = 0; while (o < b.length) { int n = in.read(b, o, b.length - o); if (n < 0) break; o += n; } } finally { in.close(); }
        return Base64.encodeToString(b, Base64.NO_WRAP);
      } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void deleteFile(String name) { File f = savesFile(name); if (f != null) f.delete(); }
    @JavascriptInterface public String listFiles() {
      StringBuilder sb = new StringBuilder("[");
      File[] l = savesDir().listFiles();
      boolean first = true;
      if (l != null) for (File f : l) {
        if (!f.getName().toLowerCase().endsWith(".glpstate")) continue;
        if (!first) sb.append(','); first = false;
        sb.append("{\"name\":\"").append(f.getName().replace("\"", "")).append("\",\"size\":").append(f.length()).append(",\"mtime\":").append(f.lastModified()).append('}');
      }
      return sb.append(']').toString();
    }


    /** Hosts heard on the network right now (rooms included) — instant. */
    @JavascriptInterface public String hosts() { return watcher.hostsJson(); }

    // ---- find hosts automatically (UDP beacon + subnet scan) ----
    @JavascriptInterface public void discoverAsync() {
      LanServer.discover(2200, new LanServer.Found() { @Override public void done(String json) { toJs("__mgsDisc", json); } });
    }

    // ---- hotspot (host) / Wi-Fi (client) ----
    // Android cannot choose the name/password of an app-made hotspot, so the host turns on the phone's own
    // hotspot (named ...gba, password 0123456789) -- we open that settings page and tell the page what to type.
    @JavascriptInterface public void startHotspot() { runOnUiThread(new Runnable() { @Override public void run() {
      try {
        Intent t = new Intent(Intent.ACTION_MAIN);
        t.setClassName("com.android.settings", "com.android.settings.TetherSettings");
        startActivity(t);
      } catch (Exception e) {
        try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception ignored) {}
      }
      toJs("__mgsHot", "{\"ok\":true,\"manual\":true,\"ssid\":\"GBA-Party-gba\",\"pass\":\"" + GBA_PASS + "\"}");
    } }); }
    /** Client: join the Wi-Fi whose name ends with "gba" (password fixed) without typing anything. */
    @JavascriptInterface public void joinGba() { runOnUiThread(new Runnable() { @Override public void run() { beginJoin(); } }); }
    @JavascriptInterface public void stopHotspot() { runOnUiThread(new Runnable() { @Override public void run() { try { if (hotspot != null) hotspot.close(); } catch (Exception ignored) {} hotspot = null; } }); }
    @JavascriptInterface public void openWifi() {
      runOnUiThread(new Runnable() { @Override public void run() {
        try {
          if (Build.VERSION.SDK_INT < 29) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm != null && !wm.isWifiEnabled()) wm.setWifiEnabled(true);
          }
          startActivity(new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_INTERNET_CONNECTIVITY : Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) {} }
      } });
    }

    /** Hide the system bars only while a game is running (immersive mode closes the soft keyboard). */
    @JavascriptInterface
    public void immersive(final boolean on) {
      immersive = on;
      runOnUiThread(new Runnable() { @Override public void run() { applySystemUi(); } });
    }
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Keep the screen on while playing (a sleeping phone is dropped from the room).
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    watcher.start();
    // Capacitor may already have started loading the page; a reload makes sure the
    // interface exists before the page's scripts run.
    getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "MgsNative");
    getBridge().getWebView().reload();
  }


  private void beginJoin() {
    if (Build.VERSION.SDK_INT < 29) {
      // Old Android: just switch Wi-Fi on; the user picks the ...gba network once and it is remembered.
      try { WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE); if (wm != null && !wm.isWifiEnabled()) wm.setWifiEnabled(true); startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) {}
      toJs("__mgsJoin", "{\"ok\":false,\"why\":\"manual\"}");
      return;
    }
    try {
      final ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
      if (joinCb != null) { try { cm.unregisterNetworkCallback(joinCb); } catch (Exception ignored) {} joinCb = null; }
      WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
          .setSsidPattern(new PatternMatcher("*gba", PatternMatcher.PATTERN_ADVANCED_GLOB))
          .setWpa2Passphrase(GBA_PASS).build();
      NetworkRequest req = new NetworkRequest.Builder()
          .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
          .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
          .setNetworkSpecifier(spec).build();
      joinCb = new ConnectivityManager.NetworkCallback() {
        @Override public void onAvailable(Network n) {
          try { cm.bindProcessToNetwork(n); } catch (Exception ignored) {}
          toJs("__mgsJoin", "{\"ok\":true}");
        }
        @Override public void onUnavailable() { toJs("__mgsJoin", "{\"ok\":false,\"why\":\"not-found\"}"); }
        @Override public void onLost(Network n) { try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {} }
      };
      cm.requestNetwork(req, joinCb, 40000);
    } catch (Exception e) {
      toJs("__mgsJoin", "{\"ok\":false,\"why\":\"" + String.valueOf(e.getMessage()).replace("\"", "'") + "\"}");
    }
  }

  private void beginHotspot() {
    if (Build.VERSION.SDK_INT < 26) { toJs("__mgsHot", "{\"ok\":false,\"why\":\"unsupported\"}"); return; }
    final String perm = Build.VERSION.SDK_INT >= 33 ? "android.permission.NEARBY_WIFI_DEVICES" : Manifest.permission.ACCESS_FINE_LOCATION;
    if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
      pendingHotspot = true;
      requestPermissions(new String[] { perm }, REQ_HOTSPOT);
      return;
    }
    try {
      if (hotspot != null) { try { hotspot.close(); } catch (Exception ignored) {} hotspot = null; }
      WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
      wm.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
        @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation r) {
          hotspot = r;
          String ssid = "", pass = "";
          try {
            if (Build.VERSION.SDK_INT >= 30) {
              SoftApConfiguration c = r.getSoftApConfiguration();
              pass = c.getPassphrase() == null ? "" : c.getPassphrase();
              ssid = Build.VERSION.SDK_INT >= 33 && c.getWifiSsid() != null ? c.getWifiSsid().toString() : (c.getSsid() == null ? "" : c.getSsid());
            } else {
              WifiConfiguration c = r.getWifiConfiguration();
              ssid = c.SSID == null ? "" : c.SSID; pass = c.preSharedKey == null ? "" : c.preSharedKey;
            }
          } catch (Exception ignored) {}
          ssid = ssid.replace("\"", ""); pass = pass.replace("\"", "");
          toJs("__mgsHot", "{\"ok\":true,\"ssid\":\"" + ssid.replace("\\", "\\\\") + "\",\"pass\":\"" + pass.replace("\\", "\\\\") + "\"}");
        }
        @Override public void onFailed(int reason) { toJs("__mgsHot", "{\"ok\":false,\"why\":\"failed " + reason + "\"}"); }
        @Override public void onStopped() { hotspot = null; }
      }, new Handler(Looper.getMainLooper()));
    } catch (Exception e) {
      toJs("__mgsHot", "{\"ok\":false,\"why\":\"" + String.valueOf(e.getMessage()).replace("\"", "'") + "\"}");
    }
  }

  @Override
  public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
    super.onRequestPermissionsResult(code, perms, res);
    if (code == REQ_HOTSPOT && pendingHotspot) {
      pendingHotspot = false;
      if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) beginHotspot();
      else toJs("__mgsHot", "{\"ok\":false,\"why\":\"permission\"}");
    }
  }

  private void applySystemUi() {
    View d = getWindow().getDecorView();
    if (immersive) {
      d.setSystemUiVisibility(
          View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
          | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    } else {
      d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) applySystemUi();
  }

  @Override
  public void onDestroy() {
    watcher.stop();
    if (lan != null) lan.stop();
    try { if (hotspot != null) hotspot.close(); } catch (Exception ignored) {}
    try { if (joinCb != null) ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(joinCb); } catch (Exception ignored) {}
    super.onDestroy();
  }
}
