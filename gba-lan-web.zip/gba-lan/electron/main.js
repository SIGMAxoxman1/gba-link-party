// Desktop shell (Windows / Linux): starts the local server inside the app and shows the UI in its own window.
const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');
const { start } = require('../server');
const { discover, createWatcher } = require('../lan-discovery');
const watcher = createWatcher();
const hotspot = require('./hotspot');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// Real LAN addresses for WebRTC (no mDNS-obfuscated candidates) so peers on the Wi-Fi find each other.
app.commandLine.appendSwitch('disable-features', 'WebRtcHideLocalIpsWithMdns');

if (!app.requestSingleInstanceLock()) app.quit();

// ---- save files: Documents/GBA Link Party/Saves ------------------------------------------
function savesDir() {
  const d = path.join(app.getPath('documents'), 'GBA Link Party', 'Saves');
  fs.mkdirSync(d, { recursive: true });
  return d;
}
const okName = (n) => (typeof n === 'string' && /\.glpstate$/i.test(n) ? path.basename(n) : null);
ipcMain.on('files:dir', (e) => { try { e.returnValue = savesDir(); } catch (_) { e.returnValue = ''; } });
ipcMain.handle('files:write', async (_e, name, bytes) => {
  const n = okName(name); if (!n) throw new Error('bad name');
  const f = path.join(savesDir(), n), tmp = f + '.tmp';
  await fs.promises.writeFile(tmp, Buffer.from(bytes)); await fs.promises.rename(tmp, f);
});
ipcMain.handle('files:read', async (_e, name) => {
  const n = okName(name); if (!n) return null;
  try { return await fs.promises.readFile(path.join(savesDir(), n)); } catch (_) { return null; }
});
ipcMain.handle('files:del', async (_e, name) => { const n = okName(name); if (n) { try { await fs.promises.unlink(path.join(savesDir(), n)); } catch (_) {} } });
ipcMain.handle('files:list', async () => {
  const d = savesDir(); const out = [];
  for (const n of await fs.promises.readdir(d)) {
    if (!okName(n)) continue;
    const st = await fs.promises.stat(path.join(d, n)); out.push({ name: n, size: st.size, mtime: st.mtimeMs });
  }
  return out;
});

ipcMain.handle('net:discover', () => discover({ timeout: 2200 }));
ipcMain.handle('net:hosts', () => watcher.hosts());
ipcMain.handle('net:hotspot-start', () => hotspot.start());
ipcMain.handle('net:hotspot-stop', () => hotspot.stop());
ipcMain.handle('net:wifi', () => hotspot.openWifi());
app.on('before-quit', () => { hotspot.stop().catch(() => {}); });

let win;
app.whenReady().then(async () => {
  let port;
  try { port = await start(8090, true); } catch (e) { console.error(e); app.quit(); return; }
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1100, height: 760, minWidth: 360, minHeight: 480,
    backgroundColor: '#0e1116', title: 'GBA Link Party', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false },
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
  });
  win.loadURL(`http://127.0.0.1:${port}/`);
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
