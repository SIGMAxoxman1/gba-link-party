// Desktop shell (Windows / Linux): starts the local server inside the app and shows the UI in its own window.
const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const { start } = require('../server');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// Real LAN addresses for WebRTC (no mDNS-obfuscated candidates) so peers on the Wi-Fi find each other.
app.commandLine.appendSwitch('disable-features', 'WebRtcHideLocalIpsWithMdns');

if (!app.requestSingleInstanceLock()) app.quit();

let win;
app.whenReady().then(async () => {
  let port;
  try { port = await start(8090, true); } catch (e) { console.error(e); app.quit(); return; }
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1100, height: 760, minWidth: 360, minHeight: 480,
    backgroundColor: '#0e1116', title: 'GBA Link Party', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false },
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
  });
  win.loadURL(`http://127.0.0.1:${port}/`);
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
