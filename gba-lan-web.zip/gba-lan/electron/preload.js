const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('mgsDesktop', true);
