const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mgsDesktop', true);
// Save files live in Documents/GBA Link Party/Saves (named after the program).
const dir = ipcRenderer.sendSync('files:dir');
contextBridge.exposeInMainWorld('mgsFiles', {
  dir,
  write: (name, bytes) => ipcRenderer.invoke('files:write', name, bytes),
  read: (name) => ipcRenderer.invoke('files:read', name),
  del: (name) => ipcRenderer.invoke('files:del', name),
  list: () => ipcRenderer.invoke('files:list'),
});
contextBridge.exposeInMainWorld('mgsNet', {
  discover: () => ipcRenderer.invoke('net:discover'),
  startHotspot: () => ipcRenderer.invoke('net:hotspot-start'),
  stopHotspot: () => ipcRenderer.invoke('net:hotspot-stop'),
  openWifi: () => ipcRenderer.invoke('net:wifi'),
});
