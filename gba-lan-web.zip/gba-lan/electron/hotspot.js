// Start / stop a Wi-Fi hotspot (host) or switch Wi-Fi on (client) from the desktop app. Best effort:
//  Linux  -> NetworkManager (nmcli)       Windows -> Mobile Hotspot through PowerShell (WinRT)
const { execFile } = require('child_process');
const { shell } = require('electron');

const run = (cmd, args, timeout) => new Promise((resolve) => {
  execFile(cmd, args, { timeout: timeout || 25000, windowsHide: true }, (err, stdout, stderr) => resolve({ ok: !err, out: String(stdout || ''), err: String(stderr || (err && err.message) || '') }));
});
// Fixed on every device on purpose: nobody types or reads anything, the clients just look for a
// network whose name ends with 'gba' and join it with this password.
const SSID = 'GBA-Party-gba', PASS = '0123456789';
const rnd = (n) => { const a = 'abcdefghjkmnpqrstuvwxyz23456789'; let s = ''; for (let i = 0; i < n; i++) s += a[Math.floor(Math.random() * a.length)]; return s; };

async function start() {
  const ssid = SSID, pass = PASS;
  if (process.platform === 'linux') {
    const dev = await run('nmcli', ['-t', '-f', 'DEVICE,TYPE', 'device']);
    const wifi = dev.out.split('\n').map((l) => l.split(':')).find((p) => p[1] === 'wifi');
    if (!dev.ok || !wifi) return { ok: false, why: 'no Wi-Fi adapter / NetworkManager' };
    await run('nmcli', ['radio', 'wifi', 'on']);
    const r = await run('nmcli', ['device', 'wifi', 'hotspot', 'ifname', wifi[0], 'con-name', 'GBA-Party-Hotspot', 'ssid', ssid, 'password', pass]);
    return r.ok ? { ok: true, ssid, pass } : { ok: false, why: r.err.trim().slice(0, 140) };
  }
  if (process.platform === 'win32') {
    const ps = `
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask=([System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1'})[0]
function Await($op,$t){$m=$asTask.MakeGenericMethod($t);$x=$m.Invoke($null,@($op));$x.Wait(-1)|Out-Null;$x.Result}
function AwaitA($op){$m=([System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and !$_.IsGenericMethod})[0];$x=$m.Invoke($null,@($op));$x.Wait(-1)|Out-Null}
[Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]|Out-Null
[Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]|Out-Null
$p=[Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
if($p -eq $null){throw 'No network connection profile (connect to any network once, or use the Windows Mobile Hotspot setting)'}
$m=[Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($p)
$c=New-Object Windows.Networking.NetworkOperators.NetworkOperatorTetheringAccessPointConfiguration
$c.Ssid='${ssid}';$c.Passphrase='${pass}'
AwaitA ($m.ConfigureAccessPointAsync($c))
$r=Await ($m.StartTetheringAsync()) ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
if($r.Status -ne 'Success'){throw ('Hotspot: '+$r.Status+' '+$r.AdditionalErrorMessage)}
'ok'`;
    const r = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], 40000);
    if (r.ok && /ok/.test(r.out)) return { ok: true, ssid, pass };
    // Mobile Hotspot refuses to start without an internet connection. The old hosted network
    // needs no internet at all (works on most Wi-Fi adapters).
    await run('netsh', ['wlan', 'set', 'hostednetwork', 'mode=allow', 'ssid=' + ssid, 'key=' + pass]);
    const h = await run('netsh', ['wlan', 'start', 'hostednetwork']);
    if (h.ok && !/not|could not|failed/i.test(h.out)) { hosted = true; return { ok: true, ssid, pass }; }
    return { ok: false, why: ((r.err || r.out) + ' | ' + (h.out || h.err)).trim().slice(0, 220) };
  }
  return { ok: false, why: 'unsupported' };
}

let hosted = false;
async function stop() {
  if (process.platform === 'win32' && hosted) { hosted = false; await run('netsh', ['wlan', 'stop', 'hostednetwork']); }
  if (process.platform === 'linux') await run('nmcli', ['connection', 'down', 'GBA-Party-Hotspot']);
  else if (process.platform === 'win32') {
    await run('powershell.exe', ['-NoProfile', '-Command', `
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]|Out-Null
[Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]|Out-Null
$p=[Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
if($p){$m=[Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($p);$f=([System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1'})[0].MakeGenericMethod([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult]);$f.Invoke($null,@($m.StopTetheringAsync())).Wait(-1)|Out-Null}`], 30000);
  }
  return { ok: true };
}

async function openWifi() {
  if (process.platform === 'linux') { await run('nmcli', ['radio', 'wifi', 'on']); return { ok: true }; }
  if (process.platform === 'win32') { await shell.openExternal('ms-settings:network-wifi'); return { ok: true }; }
  return { ok: false };
}

// Client: find a Wi-Fi network whose name ends with 'gba' and join it (password is fixed).
async function join() {
  const ends = (n) => /gba$/i.test((n || '').trim());
  if (process.platform === 'linux') {
    await run('nmcli', ['radio', 'wifi', 'on']);
    await run('nmcli', ['device', 'wifi', 'rescan'], 8000);
    const l = await run('nmcli', ['-t', '-f', 'SSID', 'device', 'wifi', 'list']);
    const ssid = l.out.split('\n').map((x) => x.trim()).find(ends);
    if (!ssid) return { ok: false, why: 'not-found' };
    const r = await run('nmcli', ['device', 'wifi', 'connect', ssid, 'password', PASS], 30000);
    return r.ok ? { ok: true, ssid } : { ok: false, why: r.err.trim().slice(0, 140) };
  }
  if (process.platform === 'win32') {
    await run('netsh', ['wlan', 'show', 'networks', 'mode=bssid'], 10000);
    const l = await run('netsh', ['wlan', 'show', 'networks'], 10000);
    const m = l.out.split(/\r?\n/).map((x) => /^\s*SSID \d+\s*:\s*(.*)$/.exec(x)).filter(Boolean).map((x) => x[1].trim()).find(ends);
    if (!m) return { ok: false, why: 'not-found' };
    const fs = require('fs'), os = require('os'), path = require('path');
    const hex = Buffer.from(m, 'utf8').toString('hex').toUpperCase();
    const xml = `<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"><name>${m}</name><SSIDConfig><SSID><hex>${hex}</hex><name>${m}</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode><MSM><security><authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption><sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>${PASS}</keyMaterial></sharedKey></security></MSM></WLANProfile>`;
    const f = path.join(os.tmpdir(), 'glp-wifi.xml'); fs.writeFileSync(f, xml);
    await run('netsh', ['wlan', 'add', 'profile', 'filename=' + f, 'user=current']);
    try { fs.unlinkSync(f); } catch (_) {}
    const r = await run('netsh', ['wlan', 'connect', 'name=' + m, 'ssid=' + m], 20000);
    return r.ok ? { ok: true, ssid: m } : { ok: false, why: (r.err || r.out).trim().slice(0, 140) };
  }
  return { ok: false, why: 'unsupported' };
}

module.exports = { start, stop, openWifi, join, SSID, PASS };
