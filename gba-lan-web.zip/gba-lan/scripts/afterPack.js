// Trim files the app never uses from the packed Electron folder (smaller installer).
const fs = require('fs'), path = require('path');
const DROP = [/^vk_swiftshader/i, /^vulkan-1\.dll$/i, /^libvk_swiftshader/i, /^libvulkan/i, /^vk_swiftshader_icd\.json$/i, /^LICENSE\.electron\.txt$/i];
function walkTop(dir) { try { return fs.readdirSync(dir); } catch (_) { return []; } }
exports.default = async function (ctx) {
  const dir = ctx.appOutDir; let saved = 0;
  for (const f of walkTop(dir)) {
    if (DROP.some((r) => r.test(f))) { try { const p = path.join(dir, f); saved += fs.statSync(p).size; fs.rmSync(p, { force: true }); } catch (_) {} }
  }
  console.log('afterPack: removed', (saved / 1048576).toFixed(1), 'MB of unused files');
};
