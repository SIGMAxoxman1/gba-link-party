// electron-builder's Go parser chokes on peer's string "binary" field; drop it (only used by the peer CLI).
const fs = require('fs'), p = require('path').join(__dirname, '..', 'node_modules', 'peer', 'package.json');
const j = JSON.parse(fs.readFileSync(p, 'utf8'));
if (typeof j.binary === 'string') { delete j.binary; fs.writeFileSync(p, JSON.stringify(j, null, 2)); console.log('patched peer/package.json'); }
