const { Lockstep } = require('../public/lockstep.js');
function rng(seed){let s=seed>>>0;return()=>(s=(Math.imul(s,1664525)+1013904223)>>>0);}
const R=rng(5);
function mkEngine(players){
  const e={st:1,keys:new Array(players).fill(0),
    setKeys(s,k){e.keys[s]=k;},
    run(){let h=e.st;for(const k of e.keys){h=(Math.imul(h^k,16777619)+7)>>>0;}e.st=h;},
    hashVideo(){return e.st;},
    saveStates(){return [e.st];},
    loadStates(a){e.st=a[0];}};
  return e;
}
function world({players,latency,jitter}){
  const net=[];let now=0;const devs=[];
  const mk=(isHost,owned,id)=>{
    const engine=mkEngine(players);
    const d={id,isHost,owned,engine,alarms:0,alive:true};
    const deliver=(to,msg,from)=>net.push({at:now+latency+(R()%(jitter+1)),to,msg,from});
    d.ls=new Lockstep({players,owned,isHost,delay:4,engine,
      send:m=>{ if(!d.alive)return; if(isHost)devs.filter(x=>!x.isHost&&x.alive).forEach(g=>deliver(g,m,d)); else deliver(devs[0],m,d);},
      relay:(m,ex)=>devs.filter(x=>!x.isHost&&x!==ex&&x.alive).forEach(g=>deliver(g,m,d)),
      onDesync:()=>{d.alarms++;}});
    devs.push(d);return d;};
  return {devs,mk,step(drive){
    for(let i=net.length-1;i>=0;i--){const m=net[i];if(m.at<=now){net.splice(i,1);if(m.to.alive)m.to.ls.receive(m.msg,m.from);}}
    for(const d of devs){if(!d.alive)continue;drive(d);for(let k=0;k<2;k++)if(!d.ls.tick())break;}
    now++;},net};
}
const drive=d=>{if(R()%5===0)for(const s of d.owned)d.ls.setLocalKeys(s,R()%1024);};
let fail=0;
// 1. desync detection + resync
{
  const w=world({players:2,latency:2,jitter:1});
  const h=w.mk(true,[0],'h'),g=w.mk(false,[1],'g');
  const snap=h.ls.makeSnapshot();g.ls.applySnapshot(snap);
  for(let t=0;t<800;t++)w.step(drive);
  g.engine.st^=0xdead; // corrupt
  for(let t=0;t<800;t++)w.step(drive);
  console.log('alarms after corruption:',h.alarms); if(!h.alarms){fail++;console.log('FAIL no alarm');}
  // resync: host snapshot -> guest
  const s2=h.ls.makeSnapshot();g.ls.applySnapshot(s2);
  // guest must not be ahead of host frame; frames between are re-simulated by both; check identity continues
  h.alarms=0;
  for(let t=0;t<1200;t++)w.step(drive);
  // compare at equal frames: run both until frames equal is not guaranteed; compare via hist
  console.log('after resync alarms:',h.alarms,'frames',h.ls.frame,g.ls.frame);
  if(h.alarms){fail++;console.log('FAIL alarm after resync');}
}
// 2. takeOver when guest leaves
{
  const w=world({players:3,latency:3,jitter:2});
  const h=w.mk(true,[0],'h'),a=w.mk(false,[1],'a'),b=w.mk(false,[2],'b');
  const snap=h.ls.makeSnapshot();a.ls.applySnapshot(snap);b.ls.applySnapshot(snap);
  for(let t=0;t<500;t++)w.step(drive);
  b.alive=false; // b vanishes
  h.ls.takeOver(2);
  const f0=h.ls.frame;
  for(let t=0;t<800;t++)w.step(drive);
  console.log('frames h/a after b left:',h.ls.frame,a.ls.frame,'(was',f0+')');
  if(h.ls.frame-f0<400||a.ls.frame-f0<400){fail++;console.log('FAIL stalled after leave');}
  // states equal at same frame? compare engine hashes by running until equal frame count
}
console.log(fail?'FAILED':'ALL OK');process.exit(fail?1:0);
