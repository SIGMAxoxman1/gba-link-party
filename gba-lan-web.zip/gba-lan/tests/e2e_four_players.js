const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const ROM = '/home/claude/spuds0588/mgba-splitscreen/cinema/gba/irq/keyirq/test.gba';
const BASE = 'http://127.0.0.1:8191/';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-features=WebRtcHideLocalIpsWithMdns'] });
  const mk = async () => { const c = await browser.newContext(); const p = await c.newPage(); p.on('pageerror', (e) => console.log('PAGEERR', e.message)); await p.goto(BASE); await p.evaluate(() => { window.__d = 0; window.MgsRoom.on('desync', () => window.__d++); }); return p; };
  const host = await mk(); const gs = [await mk(), await mk(), await mk()];
  await host.click('#go-create'); await host.setInputFiles('#c-file-input', ROM); await host.click('#c-players button[data-n="4"]'); await host.click('#c-make');
  await host.waitForSelector('#h-code:not(:empty)'); const code = await host.textContent('#h-code');
  for (const g of gs) { await g.goto(BASE + '?room=' + code); await g.evaluate(() => { window.__d = 0; window.MgsRoom.on('desync', () => window.__d++); }); await g.click('#j-go'); await g.waitForSelector('[data-s=guestlobby]:not([hidden])'); await g.setInputFiles('#g-file-input', ROM); }
  await host.waitForFunction(() => !document.querySelector('#h-start').disabled);
  await host.click('#h-start'); await sleep(3000);
  const snap = async () => Promise.all([host, ...gs].map((p) => p.evaluate(() => ({ f: window.MgsRoom.stats().frame, st: window.MgsRoom.stats().stalled, d: window.__d }))));
  const a = await snap(); await sleep(15000); const c = await snap();
  console.log('frames/s per device over 15s:', c.map((x, i) => ((x.f - a[i].f) / 15).toFixed(1)).join(' / '), 'desync alarms:', c.map((x) => x.d).join('/'));
  // random mashing on all devices for 10s
  for (let i = 0; i < 40; i++) { const k = ['ArrowUp', 'ArrowDown', 'z', 'x', 'Enter'][i % 5]; for (const p of [host, ...gs]) { p.keyboard.down(k).catch(() => {}); } await sleep(120); for (const p of [host, ...gs]) { p.keyboard.up(k).catch(() => {}); } await sleep(120); }
  await sleep(2000);
  const d = await snap(); console.log('after mashing: alarms', d.map((x) => x.d).join('/'), 'frames', d.map((x) => x.f).join('/'));
  await browser.close();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
