// Finds / announces GBA Link Party hosts on the local network (no typing of IP addresses).
//  - beacon: a host broadcasts "I am here" over UDP every 1.5 s
//  - discover: a guest listens for beacons AND scans its /24 subnet(s) for the host's /info page
const dgram = require('dgram');
const http = require('http');
const os = require('os');

const BEACON_PORT = 8091;
const SCAN_PORTS = [8090, 8091, 8092, 8093];

function ifaces() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const i of list || []) {
      if (i.family !== 'IPv4' || i.internal) continue;
      const ip = i.address.split('.').map(Number), m = i.netmask.split('.').map(Number);
      const bcast = ip.map((b, k) => (b & m[k]) | (~m[k] & 255)).join('.');
      out.push({ name, ip: i.address, bcast, base: ip.slice(0, 3).join('.') });
    }
  }
  return out;
}

function startBeacon(getPort, getRoom) {
  let sock; let timer;
  try {
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('error', () => {});
    sock.bind(0, () => { try { sock.setBroadcast(true); } catch (_) {} });
    timer = setInterval(() => {
      const msg = Buffer.from(JSON.stringify({ app: 'glp', port: getPort(), name: os.hostname(), room: (getRoom && getRoom()) || null }));
      const targets = new Set(['255.255.255.255']);
      ifaces().forEach((i) => targets.add(i.bcast));
      targets.forEach((t) => { try { sock.send(msg, BEACON_PORT, t); } catch (_) {} });
    }, 700);
    timer.unref && timer.unref();
  } catch (_) {}
  return () => { clearInterval(timer); try { sock.close(); } catch (_) {} };
}

function probe(ip, port, timeout) {
  return new Promise((resolve) => {
    const req = http.get({ host: ip, port, path: '/info', timeout }, (res) => {
      let b = ''; res.on('data', (c) => { b += c; if (b.length > 4096) req.destroy(); });
      res.on('end', () => { try { const j = JSON.parse(b); resolve(j && j.port ? { ip, port: j.port, name: j.name || '', room: j.room || null } : null); } catch (_) { resolve(null); } });
    });
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.on('error', () => resolve(null));
  });
}

async function discover(opts) {
  const o = Object.assign({ timeout: 1800, ports: SCAN_PORTS, extra: [], includeSelf: false }, opts);
  const found = new Map();
  const add = (h) => { if (h) found.set(h.ip + ':' + h.port, h); };
  // 1) beacons
  let sock;
  try {
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('error', () => {});
    sock.on('message', (buf, rinfo) => { try { const j = JSON.parse(buf.toString()); if (j && j.app === 'glp' && j.port) add({ ip: rinfo.address, port: j.port, name: j.name || '' }); } catch (_) {} });
    sock.bind(BEACON_PORT);
  } catch (_) {}
  // 2) subnet scan (works even when the router drops broadcasts)
  const jobs = [];
  for (const i of ifaces()) for (let n = 1; n < 255; n++) { const ip = i.base + '.' + n; if (ip !== i.ip) for (const p of o.ports) jobs.push([ip, p]); }
  for (const e of o.extra) jobs.push(e);
  const deadline = Date.now() + o.timeout;
  let idx = 0;
  const worker = async () => { while (idx < jobs.length && Date.now() < deadline) { const [ip, p] = jobs[idx++]; add(await probe(ip, p, 450)); } };
  await Promise.all(Array.from({ length: 96 }, worker));
  const left = deadline - Date.now();
  if (left > 0) await new Promise((r) => setTimeout(r, Math.min(left, 600)));
  try { sock.close(); } catch (_) {}
  const mine = new Set(ifaces().map((i) => i.ip).concat(['127.0.0.1']));
  return [...found.values()].filter((h) => o.includeSelf || !mine.has(h.ip));
}

// Always-on watcher (guest side): remembers every host heard in the last few seconds, so the UI can
// show rooms the instant a host appears. Beacons give it in <1 s; a subnet scan is the fallback.
function createWatcher(opts) {
  const includeSelf = !!(opts && opts.includeSelf);
  const hosts = new Map();
  let sock, scanTimer, lastBeacon = 0, scanning = false, stopped = false;
  const mine = () => new Set(ifaces().map((i) => i.ip).concat(['127.0.0.1']));
  const put = (h, via) => { if (!h || (!includeSelf && mine().has(h.ip))) return; hosts.set(h.ip + ':' + h.port, Object.assign({}, h, { seen: Date.now(), via })); };
  try {
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('error', () => {});
    sock.on('message', (buf, rinfo) => {
      try { const j = JSON.parse(buf.toString()); if (j && j.app === 'glp' && j.port) { lastBeacon = Date.now(); put({ ip: rinfo.address, port: j.port, name: j.name || '', room: j.room || null }, 'beacon'); } } catch (_) {}
    });
    sock.bind(BEACON_PORT);
  } catch (_) {}
  async function scan() {
    if (scanning || stopped) return; scanning = true;
    const jobs = [];
    for (const i of ifaces()) for (let n = 1; n < 255; n++) { const ip = i.base + '.' + n; if (ip !== i.ip) for (const p of SCAN_PORTS) jobs.push([ip, p]); }
    let idx = 0;
    const worker = async () => { while (idx < jobs.length && !stopped) { const [ip, p] = jobs[idx++]; put(await probe(ip, p, 400), 'scan'); } };
    await Promise.all(Array.from({ length: 96 }, worker));
    scanning = false;
  }
  // beacons blocked by the router? fall back to scanning every few seconds
  scanTimer = setInterval(() => { if (Date.now() - lastBeacon > 3000) scan(); }, 3000);
  scanTimer.unref && scanTimer.unref();
  setTimeout(() => { if (Date.now() - lastBeacon > 1500) scan(); }, 800);
  return {
    hosts() { const now = Date.now(); for (const [k, h] of hosts) if (now - h.seen > 4000) hosts.delete(k); return [...hosts.values()].map(({ ip, port, name, room }) => ({ ip, port, name, room })); },
    stop() { stopped = true; clearInterval(scanTimer); try { sock.close(); } catch (_) {} },
  };
}

module.exports = { startBeacon, discover, createWatcher, ifaces, BEACON_PORT };
