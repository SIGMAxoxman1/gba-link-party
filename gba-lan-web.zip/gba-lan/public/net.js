/* Network helpers: find the host automatically, start/stop a hotspot, open Wi-Fi.
 * Works in the desktop app (Electron IPC), the Android app (MgsNative) and, for discovery only,
 * falls back to "the server that served this page" in a plain browser. */
(function () {
  const D = window.mgsNet, N = window.MgsNative;
  const hasAndroid = !!(N && N.discoverAsync);
  const pending = {};
  window.__mgsDisc = (list) => { if (pending.disc) { pending.disc(list || []); pending.disc = null; } };
  window.__mgsHot = (r) => { if (pending.hot) { pending.hot(r || { ok: false }); pending.hot = null; } };
  const timeout = (p, ms, dflt) => Promise.race([p, new Promise((r) => setTimeout(() => r(dflt), ms))]);

  const api = {
    caps: { discover: !!(D || hasAndroid), hotspot: !!(D || (N && N.startHotspot)), wifi: !!(D || (N && N.openWifi)) },
    async discover() {
      try {
        if (D) return await timeout(D.discover(), 8000, []);
        if (hasAndroid) return await timeout(new Promise((res) => { pending.disc = res; N.discoverAsync(); }), 9000, []);
      } catch (_) {}
      return [];
    },
    async startHotspot() {
      try {
        if (D) return await timeout(D.startHotspot(), 50000, { ok: false, why: 'timeout' });
        if (N && N.startHotspot) return await timeout(new Promise((res) => { pending.hot = res; N.startHotspot(); }), 30000, { ok: false, why: 'timeout' });
      } catch (e) { return { ok: false, why: String(e && e.message || e) }; }
      return { ok: false, why: 'unsupported' };
    },
    async stopHotspot() { try { if (D) await D.stopHotspot(); else if (N && N.stopHotspot) N.stopHotspot(); } catch (_) {} },
    async openWifi() { try { if (D) await D.openWifi(); else if (N && N.openWifi) N.openWifi(); } catch (_) {} },
  };
  window.MgsNet = api;
})();
