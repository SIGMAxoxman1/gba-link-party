// LAN-only signalling: PeerJS talks to the server that served this page,
// never to the public PeerJS cloud. No STUN/TURN: same-network only.
window.MGS_PEER_OPTIONS = {
  host: location.hostname,
  port: Number(location.port) || (location.protocol === 'https:' ? 443 : 80),
  path: '/peerjs',
  secure: location.protocol === 'https:',
  config: { iceServers: [] },
};

// Desktop app / advanced: point signalling at another host ("192.168.1.5:8090").
window.MgsSetServer = function (addr) {
  const m = String(addr || '').trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '').match(/^([^:]+)(?::(\d+))?$/);
  if (!m) return false;
  window.MGS_PEER_OPTIONS.host = m[1];
  window.MGS_PEER_OPTIONS.port = Number(m[2]) || 8090;
  window.MGS_PEER_OPTIONS.secure = false;
  return true;
};

// Performance settings (the ⚙ button): lower them on a weak PC or phone.
window.mgsPerf = (function () {
  const d = { fps: 30, q: 0.62, audio: 'auto', lite: false, skipOthers: true };
  try { Object.assign(d, JSON.parse(localStorage.getItem('mgs_perf') || '{}')); } catch (_) {}
  return d;
})();
window.mgsPerfSave = function () { try { localStorage.setItem('mgs_perf', JSON.stringify(window.mgsPerf)); } catch (_) {} };
