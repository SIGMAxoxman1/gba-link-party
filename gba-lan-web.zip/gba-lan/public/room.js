/* LAN rooms: lobby + session start on top of PeerJS (WebRTC DataChannels).
 *
 * Host:  MgsRoom.createRoom({players, romBytes, romName, name})
 * Guest: MgsRoom.listRooms() / MgsRoom.joinRoom(code, name)  then
 *        MgsRoom.chooseRom(bytes)  (has the game)  or  MgsRoom.chooseStream()
 * Events (MgsRoom.on): 'roster', 'started', 'ended', 'error', 'desync', 'status'
 */
(function () {
  const PREFIX = 'mgs-room-';
  const listeners = {};
  const S = {
    role: 'none',            // 'none' | 'host' | 'guest'
    code: null, players: 2, roomName: '', romName: '', romCrc: 0, romSize: 0,
    seats: [],               // host view: [{seat,name,mode,conn,connected}]
    roster: [],              // what everybody sees: [{seat,name,mode,connected}]
    mySeat: 0, myMode: null, started: false,
    peer: null, hostConn: null, romBytes: null, lastResync: 0, resume: null, autoTimer: null,
    seen: new Map(), hostSeen: 0, hbTimer: null,
  };

  function on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); }
  function emit(ev, ...a) { (listeners[ev] || []).forEach((f) => { try { f(...a); } catch (e) { console.error(e); } }); }
  function opts() { return window.MGS_PEER_OPTIONS || {}; }
  function bridge() { return window.mgsBridge; }

  // ---- helpers --------------------------------------------------------------
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t;
  })();
  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }
  function pack(states) {
    const sizes = states.map((s) => s.length);
    const blob = new Uint8Array(sizes.reduce((a, b) => a + b, 0));
    let off = 0; for (const s of states) { blob.set(s, off); off += s.length; }
    return { sizes, blob: blob.buffer };
  }
  function unpack(sizes, blob) {
    const u = blob instanceof ArrayBuffer ? new Uint8Array(blob) : new Uint8Array(blob.buffer, blob.byteOffset, blob.byteLength);
    const out = []; let off = 0;
    for (const n of sizes) { out.push(u.slice(off, off + n)); off += n; }
    return out;
  }
  function send(conn, msg) { try { if (conn && conn.open) conn.send(msg); } catch (e) { console.warn('send', e); } }
  function randomCode() { return String(1000 + Math.floor(Math.random() * 9000)); }

  function newPeer(id) {
    if (typeof window.Peer !== 'function') throw new Error('PeerJS not loaded');
    return new Promise((resolve, reject) => {
      const peer = id ? new window.Peer(id, opts()) : new window.Peer(undefined, opts());
      const timer = setTimeout(() => reject(Object.assign(new Error('signalling timeout'), { type: 'timeout' })), 10000);
      peer.on('open', () => { clearTimeout(timer); resolve(peer); });
      peer.on('error', (e) => { clearTimeout(timer); reject(e); });
    });
  }

  // ---- discovery -------------------------------------------------------------
  async function listRooms() {
    try {
      const o = opts();
      const url = `http://${o.host || location.hostname}:${o.port || location.port}/peerjs/peerjs/peers`;
      const r = await fetch(url, { cache: 'no-store' });
      const ids = await r.json();
      return ids.filter((x) => x.startsWith(PREFIX)).map((x) => x.slice(PREFIX.length));
    } catch (_) { return []; }
  }

  // ---- roster ----------------------------------------------------------------
  function hostBuildRoster() {
    S.roster = S.seats.map((s, i) => ({ seat: i, name: s.name, mode: s.mode, connected: i === 0 ? true : !!s.connected }));
    return S.roster;
  }
  function hostBroadcastRoster() {
    const roster = hostBuildRoster();
    for (const s of S.seats) if (s.conn) send(s.conn, { t: 'roster', roster, players: S.players, started: S.started });
    emit('roster', roster);
  }
  function guestConns(filter) { return S.seats.filter((s, i) => i > 0 && s.conn && s.conn.open && (!filter || filter(s))); }

  // ---- HOST ------------------------------------------------------------------
  async function createRoom({ players, romBytes, romName, name }) {
    leave();
    S.role = 'host'; S.players = players; S.romBytes = romBytes; S.romName = romName || 'game';
    S.romCrc = crc32(romBytes); S.romSize = romBytes.length; S.roomName = name || '';
    S.seats = Array.from({ length: players }, () => ({ name: '', mode: null, conn: null, connected: false }));
    S.seats[0] = { name: name || 'Host', mode: 'sim', conn: null, connected: true };
    S.started = false; S.mySeat = 0; S.myMode = 'sim';
    let lastErr;
    for (let attempt = 0; attempt < 8; attempt++) {
      const code = randomCode();
      try { S.peer = await newPeer(PREFIX + code); S.code = code; break; }
      catch (e) { lastErr = e; if (e.type !== 'unavailable-id') break; }
    }
    if (!S.peer) { S.role = 'none'; throw lastErr || new Error('room creation failed'); }
    S.peer.on('connection', hostOnConnection);
    S.peer.on('disconnected', () => { try { S.peer.reconnect(); } catch (_) {} });
    hostBroadcastRoster();
    return S.code;
  }

  function hostOnConnection(conn) {
    conn.on('data', (m) => hostOnData(conn, m));
    conn.on('close', () => hostOnClose(conn));
    conn.on('error', () => hostOnClose(conn));
  }

  function seatOf(conn) { return S.seats.findIndex((s, i) => i > 0 && s.conn === conn); }

  function hostOnData(conn, m) {
    if (!m || typeof m !== 'object') return;
    S.seen.set(conn, Date.now());
    let seat = seatOf(conn);
    if (m.t === 'join') {
      if (seat >= 0) return;
      if (S.started) { send(conn, { t: 'full', why: 'started' }); return; }
      seat = S.seats.findIndex((s, i) => i > 0 && !s.conn);
      if (seat < 0) { send(conn, { t: 'full', why: 'full' }); return; }
      S.seats[seat] = { name: String(m.name || ('P' + (seat + 1))).slice(0, 20), mode: null, conn, connected: true };
      send(conn, { t: 'welcome', seat, players: S.players, romCrc: S.romCrc, romName: S.romName, romSize: S.romSize, roomName: S.roomName });
      hostBroadcastRoster();
      return;
    }
    if (seat < 0) return;
    if (m.t === 'hb') return;
    if (m.t === 'ready') {
      S.seats[seat].mode = m.mode === 'stream' ? 'stream' : 'sim';
      hostBroadcastRoster();
    } else if (m.t === 'in') {
      // A guest may only publish presses for its own seat.
      if (!S.started || S.seats[seat].mode !== 'sim' || !m.m) return;
      const own = {}; own[seat] = m.m[seat];
      if (own[seat] === undefined) return;
      bridge().receive({ t: 'in', f: m.f, m: own }, conn.peer);
    } else if (m.t === 'h') {
      if (S.started && S.seats[seat].mode === 'sim') bridge().receive({ t: 'h', f: m.f, h: m.h }, conn.peer);
    } else if (m.t === 'sin') {
      if (S.started && S.seats[seat].mode === 'stream') bridge().setSeatKeys(seat, (m.k >>> 0) & 0xfff);
    } else if (m.t === 'pong') {
      if (S.pongs) S.pongs(conn, m.n, m.ts);
    } else if (m.t === 'needsync') {
      hostResync();
    } else if (m.t === 'ss') {
      if (!S.started || ![1, 2, 3].includes(m.slot)) return;
      const by = S.seats[seat].name || ('P' + (seat + 1));
      (m.op === 'load' ? hostLoad(m.slot, by) : hostSave(m.slot, by)).then((r) => {
        if (!r.ok) send(conn, { t: 'ssev', ev: 'fail', why: r.why, slot: m.slot });
      });
    }
  }

  function hostOnClose(conn) {
    const seat = seatOf(conn);
    if (seat < 0) return;
    const mode = S.seats[seat].mode;
    if (S.started) {
      if (mode === 'stream') window.mgbaOnline.detachStreamGuest(conn);
      bridge().takeOver(seat);
      S.seats[seat].conn = null; S.seats[seat].connected = false;
      emit('status', { kind: 'left', seat, name: S.seats[seat].name });
    } else {
      S.seats[seat] = { name: '', mode: null, conn: null, connected: false };
    }
    hostBroadcastRoster();
  }

  function canStart() {
    const guests = S.seats.slice(1).filter((s) => s.conn);
    return guests.length >= 1 && guests.every((s) => s.mode);
  }

  // Measure round-trip time to every sim guest so the input delay (in frames) fits this network.
  function measureRtt() {
    const conns = guestConns((s) => s.mode === 'sim').map((s) => s.conn);
    if (!conns.length) return Promise.resolve(0);
    const samples = new Map(conns.map((c) => [c, []]));
    S.pongs = (conn, n, ts) => { const a = samples.get(conn); if (a) a.push(performance.now() - ts); };
    return new Promise((resolve) => {
      let n = 0;
      const tick = () => {
        if (n++ >= 8) {
          S.pongs = null;
          let worst = 0;
          samples.forEach((a) => { if (a.length) { a.sort((x, y) => x - y); worst = Math.max(worst, a[Math.floor(a.length * 0.75)]); } else worst = Math.max(worst, 80); });
          resolve(worst);
          return;
        }
        conns.forEach((c) => send(c, { t: 'ping', n, ts: performance.now() }));
        setTimeout(tick, 40);
      };
      tick();
    });
  }

  async function hostStart() {
    if (S.role !== 'host' || S.started || !canStart()) return false;
    const rtt = await measureRtt();
    // guest -> host -> guest is two hops (~ one RTT) plus one frame of tick granularity; min 3 frames.
    const delay = Math.max(3, Math.min(8, Math.ceil(rtt / 16.7) + 2));
    S.delay = delay;
    S.started = true;
    // Seats nobody took (a guest left before the start) are idle ghosts owned by the host.
    let players = S.players;
    const used = S.seats.map((s, i) => i === 0 || s.conn);
    while (players > 2 && !used[players - 1]) players--;
    const owned = [0];
    for (let i = 1; i < players; i++) {
      const s = S.seats[i];
      if (!s.conn || s.mode === 'stream') owned.push(i);
    }
    S.players = players;
    const simConns = () => guestConns((s) => s.mode === 'sim').map((s) => s.conn);
    await bridge().startSession({
      players, romBytes: S.romBytes, seat: 0, owned, isHost: true, delay,
      send: (m) => simConns().forEach((c) => send(c, m)),
      relay: (m, except) => simConns().forEach((c) => { if (c.peer !== except) send(c, m); }),
      onDesync: () => hostResync(),
    });
    if (S.resume) {
      const rs = S.resume; S.resume = null;
      if (rs.header.crc === S.romCrc && rs.states.length === players) { try { bridge().loadStates(rs.states); } catch (e) { console.warn('resume failed', e); } }
      else emit('ss', { ev: 'fail', why: 'mismatch' });
    }
    const snap = bridge().makeSnapshot();
    const { sizes, blob } = pack(snap.states);
    for (let i = 1; i < players; i++) {
      const s = S.seats[i];
      if (!s.conn) continue;
      if (s.mode === 'stream') {
        window.mgbaOnline.attachStreamGuest(s.conn, i);
        send(s.conn, { t: 'start', stream: true, seat: i, players });
      } else {
        send(s.conn, { t: 'start', seat: i, players, f: snap.f, sizes, blob, delay });
      }
    }
    bridge().go();
    startHeartbeat();
    clearInterval(S.autoTimer);
    S.autoTimer = setInterval(() => { hostSave('auto', '', true).catch(() => {}); }, 60000);
    S.roster = hostBuildRoster();
    hostBroadcastRoster();
    emit('started', { seat: 0, mode: 'sim', players });
    return true;
  }

  function hostResync(force) {
    const now = Date.now();
    if (!S.started || (force !== true && now - S.lastResync < 5000)) return;
    S.lastResync = now;
    const snap = bridge().makeSnapshot();
    const { sizes, blob } = pack(snap.states);
    guestConns((s) => s.mode === 'sim').forEach((s) => send(s.conn, { t: 'resync', f: snap.f, sizes, blob }));
    emit('desync', { resynced: true });
  }

  // ---- SAVE STATES (shared by everyone; stored as files on the host) ---------------------------
  const store = () => window.MgsStore;
  const slotFile = (slot) => store().fileName(S.romName, S.romCrc, slot);
  function announce(ev) { guestConns().forEach((s) => send(s.conn, Object.assign({ t: 'ssev' }, ev))); emit('ss', ev); }
  async function hostSave(slot, by, quiet) {
    if (S.role !== 'host' || !S.started) return { ok: false, why: 'notstarted' };
    try {
      const states = bridge().captureStates();
      const bytes = store().encode({ rom: S.romName, crc: S.romCrc, romSize: S.romSize, players: S.players, t: Date.now(), by: by || '' }, states);
      await store().put(slotFile(slot), bytes);
      if (!quiet) announce({ ev: 'saved', slot, by });
      return { ok: true };
    } catch (e) { console.warn('save failed', e); return { ok: false, why: 'fail' }; }
  }
  async function hostLoad(slot, by) {
    if (S.role !== 'host' || !S.started) return { ok: false, why: 'notstarted' };
    try {
      const d = store().decode(await store().get(slotFile(slot)));
      if (!d) return { ok: false, why: 'empty' };
      if (d.header.crc !== S.romCrc || d.states.length !== S.players) return { ok: false, why: 'mismatch' };
      bridge().loadStates(d.states);
      hostResync(true); // every device adopts the loaded state at the same moment
      announce({ ev: 'loaded', slot, by });
      return { ok: true };
    } catch (e) { console.warn('load failed', e); return { ok: false, why: 'fail' }; }
  }
  const myName = () => (S.seats[0] && S.seats[0].name) || 'Host';
  async function saveState(slot) {
    if (S.role === 'host') { const r = await hostSave(slot, myName()); if (!r.ok) emit('ss', { ev: 'fail', why: r.why, slot }); return r; }
    if (S.role === 'guest' && S.started) { send(S.hostConn, { t: 'ss', op: 'save', slot }); return { ok: true, pending: true }; }
    return { ok: false, why: 'notstarted' };
  }
  async function loadState(slot) {
    if (S.role === 'host') { const r = await hostLoad(slot, myName()); if (!r.ok) emit('ss', { ev: 'fail', why: r.why, slot }); return r; }
    if (S.role === 'guest' && S.started) { send(S.hostConn, { t: 'ss', op: 'load', slot }); return { ok: true, pending: true }; }
    return { ok: false, why: 'notstarted' };
  }
  // Saves of the chosen game (create screen): [{slot, mtime, players, by}]
  async function listSaves(romName, crc) {
    const out = [];
    for (const slot of ['auto', 1, 2, 3]) {
      try {
        const d = store().decode(await store().get(store().fileName(romName, crc, slot)));
        if (d && d.header.crc === crc) out.push({ slot, mtime: d.header.t, players: d.header.players, by: d.header.by });
      } catch (_) {}
    }
    return out;
  }
  async function useSave(romName, crc, slot) {
    if (slot == null) { S.resume = null; return null; }
    const d = store().decode(await store().get(store().fileName(romName, crc, slot)));
    S.resume = d && d.header.crc === crc ? d : null;
    return S.resume ? S.resume.header : null;
  }

  // ---- GUEST -----------------------------------------------------------------
  async function joinRoom(code, name) {
    leave();
    S.role = 'guest'; S.code = String(code).trim(); S.started = false; S.myMode = null; S.romBytes = null;
    try { S.peer = await newPeer(); }
    catch (e) { S.role = 'none'; throw e; }
    const conn = S.peer.connect(PREFIX + S.code, { reliable: true });
    S.hostConn = conn;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Object.assign(new Error('room not reachable'), { type: 'timeout' })), 12000);
      conn.on('open', () => { clearTimeout(timer); resolve(); });
      conn.on('error', (e) => { clearTimeout(timer); reject(e); });
      S.peer.on('error', (e) => { clearTimeout(timer); reject(e); });
    }).catch((e) => { leave(); throw e; });
    conn.on('data', guestOnData);
    conn.on('close', () => { if (S.role === 'guest') { emit('ended', { reason: 'host-left' }); leave(true); } });
    send(conn, { t: 'join', name: name || 'Guest', ver: 1 });
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('no welcome')), 8000);
      S._welcome = (info) => { clearTimeout(timer); resolve(info); };
      S._reject = (e) => { clearTimeout(timer); reject(e); };
    });
  }

  function guestOnData(m) {
    if (!m || typeof m !== 'object') return;
    S.hostSeen = Date.now();
    if (m.type === 'frame' || m.type === 'audio') { window.mgbaOnline.handleStreamMessage(m); return; }
    switch (m.t) {
      case 'welcome':
        S.mySeat = m.seat; S.players = m.players; S.romName = m.romName; S.romCrc = m.romCrc; S.romSize = m.romSize; S.roomName = m.roomName;
        if (S._welcome) S._welcome({ seat: m.seat, players: m.players, romName: m.romName, romSize: m.romSize, roomName: m.roomName });
        break;
      case 'full':
        if (S._reject) S._reject(Object.assign(new Error(m.why), { type: 'full', why: m.why }));
        break;
      case 'in':
        if (S.simReady) bridge().receive(m); else if (S.started) S.pendingIn.push(m);
        break;
      case 'hb': break;
      case 'ping': send(S.hostConn, { t: 'pong', n: m.n, ts: m.ts }); break;
      case 'ssev': emit('ss', m); break;
      case 'kicked': emit('ended', { reason: 'kicked' }); leave(true); break;
      case 'closed': break;
      case 'roster': S.roster = m.roster; S.players = m.players; emit('roster', m.roster); break;
      case 'start': guestStart(m); break;
      case 'resync':
        if (S.simReady) {
          bridge().applySnapshot({ f: m.f, states: unpack(m.sizes, m.blob) });
          emit('desync', { resynced: true });
        }
        break;
      default: break;
    }
  }

  // Guest has the game: verify it is the same ROM as the host's, then say "ready".
  function chooseRom(bytes, fileName) {
    const crc = crc32(bytes);
    if (crc !== S.romCrc || bytes.length !== S.romSize) {
      return { ok: false, reason: 'mismatch', expected: S.romName };
    }
    S.romBytes = bytes; S.myMode = 'sim';
    send(S.hostConn, { t: 'ready', mode: 'sim' });
    return { ok: true };
  }
  function chooseStream() {
    S.myMode = 'stream'; S.romBytes = null;
    send(S.hostConn, { t: 'ready', mode: 'stream' });
    return { ok: true };
  }

  async function guestStart(m) {
    startHeartbeat();
    S.started = true; S.simReady = false; S.pendingIn = S.pendingIn || []; S.mySeat = m.seat; S.players = m.players;
    if (m.stream) {
      bridge().enterStreamGuest(m.seat, m.players, (seat, mask) => send(S.hostConn, { t: 'sin', k: mask }));
      emit('started', { seat: m.seat, mode: 'stream', players: m.players });
      return;
    }
    await bridge().startSession({
      players: m.players, romBytes: S.romBytes, seat: m.seat, owned: [m.seat], isHost: false, delay: m.delay || 4,
      send: (msg) => send(S.hostConn, msg),
    });
    bridge().applySnapshot({ f: m.f, states: unpack(m.sizes, m.blob) });
    S.simReady = true;
    S.pendingIn.splice(0).forEach((q) => bridge().receive(q));
    bridge().go();
    emit('started', { seat: m.seat, mode: 'sim', players: m.players });
  }

  // ---- liveness ----------------------------------------------------------------
  // A device that vanishes (phone locked, wifi lost) would freeze everybody in
  // lockstep. Everyone sends a heartbeat every 2 s; silence for too long drops
  // that player (host side) or ends the game (guest side).
  const SILENT_MS = 6000;
  function startHeartbeat() {
    clearInterval(S.hbTimer);
    S.hostSeen = Date.now();
    const now = Date.now();
    S.seats.forEach((s) => { if (s.conn) S.seen.set(s.conn, now); });
    S.hbTimer = setInterval(() => {
      const t = Date.now();
      if (S.role === 'host') {
        guestConns().forEach((s) => send(s.conn, { t: 'hb' }));
        guestConns().forEach((s) => { if (t - (S.seen.get(s.conn) || t) > SILENT_MS) kick(s.conn); });
      } else if (S.role === 'guest') {
        send(S.hostConn, { t: 'hb' });
        if (S.started && t - S.hostSeen > SILENT_MS + 2000) { emit('ended', { reason: 'host-left' }); leave(true); }
      }
    }, 2000);
  }
  function kick(conn) {
    send(conn, { t: 'kicked' });
    try { conn.close(); } catch (_) {}
    hostOnClose(conn);
  }

  // ---- teardown --------------------------------------------------------------
  function leave(silent) {
    clearInterval(S.hbTimer); clearInterval(S.autoTimer); S.seen.clear();
    if (S.role === 'host' && S.started) { try { hostSave('auto', '', true); } catch (_) {} }
    try {
      if (S.role === 'host') S.seats.forEach((s, i) => { if (i > 0 && s.conn) { send(s.conn, { t: 'closed' }); try { s.conn.close(); } catch (_) {} } });
      if (S.hostConn) { try { S.hostConn.close(); } catch (_) {} }
      if (S.peer) { try { S.peer.destroy(); } catch (_) {} }
    } catch (_) {}
    if (bridge()) bridge().stopSession();
    S.role = 'none'; S.peer = null; S.hostConn = null; S.seats = []; S.roster = []; S.started = false; S.simReady = false; S.pendingIn = []; S.code = null; S.romBytes = null;
    if (!silent) emit('roster', []);
  }

  window.MgsRoom = {
    state: S, on, crc32, listRooms, createRoom, joinRoom, chooseRom, chooseStream, start: hostStart, canStart, leave,
    resync: hostResync, saveState, loadState, listSaves, useSave,
    stats: () => (bridge() ? bridge().stats() : null),
  };
})();
