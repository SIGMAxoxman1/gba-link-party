/* Simple LAN UI: home → create/join → lobby → game. Talks to MgsRoom + mgsBridge. */
(function () {
  const T = (k) => window.MgsI18n.t(k);
  const SEAT_COLORS = ['#ff6b6b', '#5aa9ff', '#7bd88f', '#ffd166'];
  const $ = (sel, root) => (root || document).querySelector(sel);
  let screen = 'home';
  let romFile = null;          // host: { bytes, name }
  let players = 2;
  let guestRom = null;         // guest: picked file (for "I have it")
  let roomsTimer = null, statsTimer = null, toastTimer = null;
  let muted = false, allView = false;

  const root = document.createElement('div');
  root.id = 'lan-app';
  root.innerHTML = `
  <section class="lan-screen" data-s="home"><div class="lan-wrap">
    <div class="lan-top"><span></span><button class="lan-pill" id="lan-lang"></button></div>
    <h1 class="lan-h1" data-i18n="title"></h1>
    <p class="lan-sub" data-i18n="tagline"></p>
    <div id="home-rooms" hidden><div class="lan-label" data-i18n="nearby"></div><div class="lan-resume" id="home-rooms-list"></div></div>
    <button class="lan-big primary" id="go-create"><strong data-i18n="create"></strong><span data-i18n="create_sub"></span></button>
    <button class="lan-big" id="go-join"><strong data-i18n="join"></strong><span data-i18n="join_sub"></span></button>
    <button class="lan-big" id="go-settings"><strong data-i18n="settings"></strong><span data-i18n="settings_sub"></span></button>
    <button class="lan-link" id="go-solo" data-i18n="solo"></button>
    <p class="lan-tip" data-i18n="tip_wifi"></p>
  </div></section>


  <section class="lan-screen" data-s="settings" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-back data-i18n="back"></button><button class="lan-pill lan-langbtn"></button></div>
    <h1 class="lan-h1" data-i18n="settings"></h1>
    <div class="lan-card">
      <div class="lan-set-row"><div><b data-i18n="s_hotui"></b><small data-i18n="s_hotui_d"></small></div><button class="lan-switch" role="switch" data-k="hotspotUi" aria-checked="false"></button></div>
      <div class="lan-set-row"><div><b data-i18n="s_lite"></b><small data-i18n="s_lite_d"></small></div><button class="lan-switch" role="switch" data-k="lite" aria-checked="false"></button></div>
      <div class="lan-set-block"><div><b data-i18n="s_audio"></b><small data-i18n="s_audio_d"></small></div><div class="lan-seg" data-k="audio"><button data-v="auto" data-i18n="a_auto"></button><button data-v="small" data-i18n="a_small"></button><button data-v="large" data-i18n="a_large"></button></div></div>
      <div class="lan-set-block"><div><b data-i18n="s_fps"></b><small data-i18n="s_fps_d"></small></div><div class="lan-seg" data-k="fps"><button data-v="30" data-i18n="30"></button><button data-v="20" data-i18n="20"></button><button data-v="15" data-i18n="15"></button></div></div>
      <div class="lan-set-block"><div><b data-i18n="s_q"></b><small data-i18n="s_q_d"></small></div><div class="lan-seg" data-k="q"><button data-v="0.8" data-i18n="q_high"></button><button data-v="0.62" data-i18n="q_mid"></button><button data-v="0.45" data-i18n="q_low"></button></div></div>
      <div class="lan-set-block" id="s-saves"><div><b data-i18n="saves_title"></b><small id="s-saves-where"></small></div><div id="s-saves-list"></div>
        <button class="lan-btn ghost" id="s-import" data-i18n="saves_import"></button><input type="file" id="s-import-input" accept=".glpstate" hidden /></div>
    </div>
    <p class="lan-tip" data-i18n="perf_tip"></p>
  </div></section>

  <section class="lan-screen" data-s="create" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-back data-i18n="back"></button><button class="lan-pill lan-langbtn"></button></div>
    <h1 class="lan-h1" data-i18n="create"></h1>
    <div class="lan-card">
      <div><div class="lan-label" data-i18n="your_name"></div><input class="lan-input" id="c-name" maxlength="20" /></div>
      <div><div class="lan-label" data-i18n="choose_game"></div>
        <button class="lan-file" id="c-file"><span style="font-size:24px">🎮</span><span><b id="c-file-name"></b><small data-i18n="game_hint"></small></span></button>
        <input type="file" id="c-file-input" accept=".gba,.gbc,.gb,.agb,.bin,.zip" hidden /></div>
      <div id="c-resume-box" hidden><div class="lan-label" data-i18n="resume_lbl"></div><div class="lan-resume" id="c-resume"></div></div>
      <div id="c-net-box" hidden><div class="lan-label" data-i18n="net_lbl"></div>
        <div class="lan-seg" id="c-net"><button class="on" data-net="wifi" data-i18n="net_wifi"></button><button data-net="hot" data-i18n="net_hot"></button></div>
        <p class="lan-tip" data-i18n="net_hot_d" style="margin:6px 0 0"></p></div>
      <div><div class="lan-label" data-i18n="players"></div>
        <div class="lan-seg" id="c-players"><button data-n="2">2</button><button data-n="3">3</button><button data-n="4">4</button></div></div>
      <p class="lan-err" id="c-err"></p>
      <button class="lan-btn" id="c-make" data-i18n="make_room"></button>
    </div>
    <p class="lan-tip" data-i18n="tip_same"></p>
  </div></section>

  <section class="lan-screen" data-s="hostlobby" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-leave data-i18n="leave"></button><button class="lan-pill lan-langbtn"></button></div>
    <div class="lan-card">
      <div class="lan-label" data-i18n="room_code"></div>
      <div class="lan-code" id="h-code"></div>
      <div class="lan-qr"><canvas id="h-qr"></canvas></div>
      <div class="lan-label" style="text-align:center" data-i18n="scan"></div>
      <div class="lan-url" id="h-url"></div>
      <div id="h-hot" hidden style="text-align:center"><div class="lan-label" data-i18n="hot_title"></div><div id="h-hot-text" class="lan-url" style="user-select:text"></div><div class="lan-qr"><canvas id="h-hot-qr"></canvas></div></div>
    </div>
    <ul class="lan-roster" id="h-roster"></ul>
    <p class="lan-tip" id="h-hint"></p>
    <button class="lan-btn" id="h-start" data-i18n="start"></button>
  </div></section>

  <section class="lan-screen" data-s="join" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-back data-i18n="back"></button><button class="lan-pill lan-langbtn"></button></div>
    <h1 class="lan-h1" data-i18n="join"></h1>
    <div class="lan-card">
      <div><div class="lan-label" data-i18n="your_name"></div><input class="lan-input" id="j-name" maxlength="20" /></div>
      <div id="j-srv-box" hidden><div class="lan-label" data-i18n="host_addr"></div><input class="lan-input" id="j-srv" placeholder="192.168.1.5:8090" style="direction:ltr" />
        <div class="lan-resume" id="j-found"></div>
        <button class="lan-btn ghost" id="j-wifi" hidden data-i18n="open_wifi" style="margin-top:8px"></button></div>
      <div class="lan-row"><div class="lan-label" data-i18n="open_rooms" style="flex:1;align-self:center"></div><button class="lan-pill" id="j-refresh" data-i18n="refresh" style="flex:none"></button></div>
      <div class="lan-rooms" id="j-rooms"></div>
      <div><div class="lan-label" data-i18n="enter_code"></div>
        <div class="lan-row"><input class="lan-input" id="j-code" inputmode="numeric" maxlength="4" style="direction:ltr;text-align:center;letter-spacing:.2em" /><button class="lan-btn" id="j-go" data-i18n="go" style="flex:none"></button></div></div>
      <p class="lan-err" id="j-err"></p>
    </div>
  </div></section>

  <section class="lan-screen" data-s="guestlobby" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-leave data-i18n="leave"></button><button class="lan-pill lan-langbtn"></button></div>
    <div class="lan-card"><div class="lan-label" data-i18n="room_code"></div><div class="lan-code" id="g-code" style="font-size:40px"></div>
      <div class="lan-sub" id="g-game" style="text-align:center"></div></div>
    <ul class="lan-roster" id="g-roster"></ul>
    <div id="g-choose" class="lan-card">
      <button class="lan-big primary" id="g-have"><strong data-i18n="i_have"></strong><span data-i18n="i_have_sub"></span></button>
      <button class="lan-big" id="g-dont"><strong data-i18n="i_dont"></strong><span data-i18n="i_dont_sub"></span></button>
      <input type="file" id="g-file-input" accept=".gba,.gbc,.gb,.agb,.bin,.zip" hidden />
      <p class="lan-err" id="g-err"></p>
    </div>
    <p class="lan-note" id="g-wait" hidden data-i18n="waiting_host"></p>
  </div></section>`;
  document.body.appendChild(root);

  const hud = document.createElement('div');
  hud.id = 'lan-hud'; hud.hidden = true;
  hud.innerHTML = `<div id="lan-hud-row"><button class="lan-mini" id="hud-qsave" aria-label="save">💾</button><button class="lan-mini" id="hud-qload" aria-label="load">📂</button><button id="lan-hud-btn" aria-label="menu">☰</button></div>
    <div id="lan-hud-panel" hidden>
      <div class="lan-slotrow"><span data-i18n="slot_lbl"></span><div class="lan-seg" id="hud-slots"><button data-slot="1">1</button><button data-slot="2">2</button><button data-slot="3">3</button></div></div>
      <button id="hud-save"></button><button id="hud-load"></button>
      <button id="hud-controls"></button><button id="hud-touch"></button><button id="hud-mute"></button><button id="hud-full"></button><button id="hud-leave" class="danger"></button>
    </div>`;
  document.body.appendChild(hud);
  const toast = document.createElement('div'); toast.id = 'lan-toast'; toast.hidden = true; document.body.appendChild(toast);
  const slow = document.createElement('div'); slow.id = 'lan-slow'; slow.hidden = true; document.body.appendChild(slow);
  const homeBtn = document.createElement('button'); homeBtn.id = 'lan-home-btn'; homeBtn.className = 'lan-pill'; homeBtn.hidden = true; homeBtn.textContent = '⌂'; document.body.appendChild(homeBtn);

  document.body.classList.add('lan-ui'); // hides the old menu bar while the party UI is active

  function nativeImmersive(on) { try { if (window.MgsNative && window.MgsNative.immersive) window.MgsNative.immersive(!!on); } catch (_) {} }
  function show(name) {
    nativeImmersive(false);
    screen = name;
    root.hidden = false;
    root.querySelectorAll('.lan-screen').forEach((s) => { s.hidden = s.dataset.s !== name; });
    hud.hidden = true;
    clearInterval(roomsTimer);
    if (name === 'join') { refreshRooms(); roomsTimer = setInterval(refreshRooms, 3000); if (window.mgsFindHosts) window.mgsFindHosts(); }
    renderLangButtons();
    window.MgsI18n.apply(root);
    updateHud();
    root.scrollTop = 0;
  }
  function renderLangButtons() {
    const l = T('lang');
    $('#lan-lang').textContent = l;
    root.querySelectorAll('.lan-langbtn').forEach((b) => { b.textContent = l; });
  }
  function say(msg, ms) {
    toast.textContent = msg; toast.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { toast.hidden = true; }, ms || 3500);
  }
  function updateHud() {
    $('#hud-mute').textContent = muted ? '🔇 ' + T('unmute') : '🔊 ' + T('mute');
    $('#hud-full').textContent = '⛶ ' + T('fullscreen');
    $('#hud-controls').textContent = '⌨ ' + T('controls');
    $('#hud-touch').textContent = '🎮 ' + T('touch_edit');
    $('#hud-touch').style.display = (navigator.maxTouchPoints > 0 || window.mgbaTouch) ? '' : 'none';
    $('#hud-leave').textContent = '⏏ ' + T('leave');
    $('#hud-save').textContent = '💾 ' + T('save_state');
    $('#hud-load').textContent = '📂 ' + T('load_state');
    document.querySelectorAll('#lan-hud-row .lan-mini').forEach((b) => { b.style.display = navigator.maxTouchPoints > 0 ? '' : 'none'; });
  }
  document.addEventListener('mgs-lang', () => { renderLangButtons(); updateHud(); renderRoster(); renderChooseState(); fileLabel(); });

  // ---- wiring: generic ------------------------------------------------------
  root.addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.id === 'lan-lang' || t.classList.contains('lan-langbtn')) window.MgsI18n.toggle();
    else if (t.hasAttribute('data-back')) show('home');
    else if (t.hasAttribute('data-leave')) { window.MgsRoom.leave(); stopHot(); show('home'); }
  });
  $('#go-create').onclick = () => { show('create'); refreshResume(); const on = !!(window.MgsNet && window.MgsNet.caps.hotspot && window.mgsPerf.hotspotUi); $('#c-net-box').hidden = !on; if (!on) { netMode = 'wifi'; root.querySelectorAll('#c-net button').forEach((x) => x.classList.toggle('on', x.dataset.net === 'wifi')); } };
  $('#go-join').onclick = () => show('join');
  $('#go-solo').onclick = () => {
    root.hidden = true; document.body.classList.remove('lan-ui'); homeBtn.hidden = false;
  };
  homeBtn.onclick = () => { homeBtn.hidden = true; document.body.classList.add('lan-ui'); show('home'); };

  // ---- create (host) --------------------------------------------------------
  function fileLabel() {
    $('#c-file-name').textContent = romFile ? `${T('chosen')}: ${romFile.name}` : T('pick_file');
    $('#c-file').classList.toggle('has', !!romFile);
  }
  function setPlayers(n) {
    players = n;
    root.querySelectorAll('#c-players button').forEach((b) => b.classList.toggle('on', Number(b.dataset.n) === n));
  }
  $('#c-players').onclick = (e) => { const b = e.target.closest('button'); if (b) setPlayers(Number(b.dataset.n)); };
  $('#c-file').onclick = () => $('#c-file-input').click();
  $('#c-file-input').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    romFile = { bytes: new Uint8Array(await f.arrayBuffer()), name: f.name.replace(/\.[^.]+$/, '') };
    fileLabel(); refreshResume();
  };
  const savedName = () => { try { return localStorage.getItem('mgs_name') || ''; } catch (_) { return ''; } };
  const saveName = (v) => { try { localStorage.setItem('mgs_name', v); } catch (_) {} };

  $('#c-make').onclick = async () => {
    const err = $('#c-err'); err.textContent = '';
    if (!romFile) { err.textContent = T('choose_game'); return; }
    if (typeof WebAssembly === 'undefined') { err.textContent = T('unsupported'); return; }
    const name = $('#c-name').value.trim() || 'Host'; saveName(name);
    $('#c-make').disabled = true;
    try {
      if (!window.mgsBridge) throw new Error('mgsBridge missing — old cached page? Press Ctrl+F5');
      await window.mgsBridge.ready();
    } catch (e2) { console.error(e2); err.textContent = T('err_engine') + ' [' + (e2 && e2.message || e2) + ']'; $('#c-make').disabled = false; return; }
    hotInfo = null;
    if (netMode === 'hot' && NET.caps.hotspot) {
      err.textContent = T('hot_starting');
      const r = await NET.startHotspot();
      if (r && r.ok) hotInfo = r; else say('⚠ ' + T('hot_fail') + (r && r.why ? ' (' + r.why + ')' : ''), 6000);
      err.textContent = '';
    }
    if (window.mgsHasServer) {
      try {
        nativeInfo = JSON.parse(window.MgsNative.startServer());
        if (!nativeInfo || !nativeInfo.port) throw new Error('no port');
        window.MgsSetServer('127.0.0.1:' + nativeInfo.port);
      } catch (e4) { console.error(e4); err.textContent = T('err_net') + ' — ' + T('err_phone_server'); $('#c-make').disabled = false; return; }
    }
    try {
      const code = await window.MgsRoom.createRoom({ players, romBytes: romFile.bytes, romName: romFile.name, name });
      showHostLobby(code);
    } catch (e3) { err.textContent = T('err_net') + (window.mgsNativeApp ? ' — ' + T('err_native_host') : ''); }
    $('#c-make').disabled = false;
  };

  let nativeInfo = null;
  async function lanBase() {
    if (nativeInfo) return 'http://' + (nativeInfo.ips && nativeInfo.ips[0] ? nativeInfo.ips[0] : '127.0.0.1') + ':' + nativeInfo.port + '/';
    let host = location.host;
    if (/^(localhost|127\.|\[::1\])/.test(location.hostname)) {
      try {
        const info = await (await fetch('/info', { cache: 'no-store' })).json();
        if (info.ips && info.ips[0]) host = info.ips[0] + ':' + info.port;
      } catch (_) {}
    }
    return `${location.protocol}//${host}/`;
  }
  async function showHostLobby(code) {
    show('hostlobby');
    announceRoom();
    $('#h-code').textContent = code;
    const url = (await lanBase()) + '?room=' + code;
    $('#h-url').textContent = url + (nativeInfo ? '\n' + T('app_addr') + ' ' + (nativeInfo.ips && nativeInfo.ips[0] || '?') + ':' + nativeInfo.port : '');
    $('#h-url').style.whiteSpace = 'pre-line';
    $('#h-hot').hidden = !hotInfo;
    if (hotInfo) {
      $('#h-hot-text').textContent = T('hot_wifi') + ' ' + hotInfo.ssid + '\n' + T('hot_pass') + ' ' + hotInfo.pass;
      $('#h-hot-text').style.whiteSpace = 'pre-line';
      try { window.QRCode.toCanvas($('#h-hot-qr'), `WIFI:T:WPA;S:${hotInfo.ssid};P:${hotInfo.pass};;`, { margin: 1, width: 150 }, () => {}); } catch (_) {}
    }
    try {
      window.QRCode.toCanvas($('#h-qr'), url, { margin: 1, width: 176 }, () => {});
    } catch (_) {}
    renderRoster();
  }

  // ---- roster ----------------------------------------------------------------
  function statusText(r) {
    if (r.seat === 0) return T('host_game');
    if (!r.connected && !r.name) return T('empty');
    if (!r.connected) return '—';
    if (r.mode === 'sim') return T('ready_sim');
    if (r.mode === 'stream') return T('ready_stream');
    return T('not_ready');
  }
  function renderRoster() {
    const S = window.MgsRoom.state;
    const roster = S.roster && S.roster.length ? S.roster : [];
    const total = S.players || roster.length;
    const rows = [];
    for (let i = 0; i < total; i++) {
      const r = roster[i] || { seat: i, name: '', connected: false };
      const empty = !r.connected && !r.name;
      const isMe = S.role === 'guest' ? i === S.mySeat : i === 0;
      rows.push(`<li class="${empty ? 'empty' : ''}"><span class="dot" style="background:${SEAT_COLORS[i]}"></span>
        <span class="nm">${empty ? '…' : esc(r.name || 'P' + (i + 1))}${isMe ? ' · ' + T('you') : ''}</span>
        <span class="st">${statusText(r)}</span></li>`);
    }
    const html = rows.join('');
    $('#h-roster').innerHTML = html; $('#g-roster').innerHTML = html;
    if (S.role === 'host') {
      const ok = window.MgsRoom.canStart();
      $('#h-start').disabled = !ok;
      const guests = roster.slice(1).filter((r) => r.connected);
      $('#h-hint').textContent = !guests.length ? T('need_one') : (ok ? '' : T('wait_ready'));
    }
  }
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  $('#h-start').onclick = async () => {
    $('#h-start').disabled = true;
    try { await window.MgsRoom.start(); }
    catch (e) { console.error(e); say(T('err_rom'), 5000); window.MgsRoom.leave(); show('home'); }
  };

  // ---- join (guest) ------------------------------------------------------------
  function applyServer() { const v = $('#j-srv').value.trim(); if (v) window.MgsSetServer(v); }
  $('#j-srv').onchange = () => { applyServer(); try { localStorage.setItem('mgs_srv', $('#j-srv').value.trim()); } catch (_) {} refreshRooms(); };
  async function refreshRooms() {
    applyServer();
    const list = await window.MgsRoom.listRooms();
    if (screen !== 'join') return;
    const box = $('#j-rooms');
    box.innerHTML = list.length
      ? list.map((c) => `<button class="lan-room" data-code="${c}"><b>${c}</b><span>▶</span></button>`).join('')
      : `<p class="lan-tip">${T('none_found')}</p>`;
  }
  $('#j-refresh').onclick = () => { refreshRooms(); if (window.mgsFindHosts) window.mgsFindHosts(); };
  $('#j-rooms').onclick = (e) => { const b = e.target.closest('.lan-room'); if (b) joinCode(b.dataset.code); };
  $('#j-go').onclick = () => joinCode($('#j-code').value.trim());
  $('#j-code').onkeydown = (e) => { if (e.key === 'Enter') joinCode($('#j-code').value.trim()); };

  async function joinCode(code) {
    applyServer();
    const err = $('#j-err'); err.textContent = '';
    if (isNativeApp && !$('#j-srv').value.trim()) { err.textContent = T('need_addr'); say(T('need_addr'), 4000); return; }
    if (!/^\d{4}$/.test(code)) { err.textContent = T('err_room'); return; }
    const name = $('#j-name').value.trim() || 'Guest'; saveName(name);
    err.textContent = T('connecting');
    try {
      let info;
      try { info = await window.MgsRoom.joinRoom(code, name); }
      catch (e0) {
        // The host may be re-registering with the server for a moment: try once more before giving up.
        if (e0 && e0.type === 'peer-unavailable') { await new Promise((r) => setTimeout(r, 1200)); info = await window.MgsRoom.joinRoom(code, name); }
        else throw e0;
      }
      err.textContent = '';
      guestRom = null;
      $('#g-code').textContent = code;
      $('#g-game').textContent = '🎮 ' + (info.romName || '');
      $('#g-err').textContent = '';
      show('guestlobby');
      renderChooseState();
      renderRoster();
    } catch (e) {
      err.textContent = e && e.type === 'full' ? (e.why === 'started' ? T('err_started') : T('err_full')) : T('err_room');
      say('⚠ ' + err.textContent, 4000);
    }
  }

  function renderChooseState() {
    const S = window.MgsRoom.state;
    const chosen = S.myMode;
    $('#g-choose').hidden = !!chosen;
    $('#g-wait').hidden = !chosen;
  }
  $('#g-have').onclick = async () => {
    if (typeof WebAssembly === 'undefined') { $('#g-err').textContent = T('unsupported'); return; }
    $('#g-file-input').click();
  };
  $('#g-file-input').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const err = $('#g-err'); err.textContent = '';
    try { if (!window.mgsBridge) throw new Error('mgsBridge missing — press Ctrl+F5'); await window.mgsBridge.ready(); } catch (e2) { err.textContent = T('err_engine') + ' [' + (e2 && e2.message || e2) + ']'; return; }
    const bytes = new Uint8Array(await f.arrayBuffer());
    const r = window.MgsRoom.chooseRom(bytes, f.name);
    if (!r.ok) { err.textContent = T('wrong_rom'); return; }
    renderChooseState();
  };
  $('#g-dont').onclick = () => { window.MgsRoom.chooseStream(); renderChooseState(); };

  // ---- room events -----------------------------------------------------------------
  window.MgsRoom.on('roster', () => { renderRoster(); renderChooseState(); if (roomTimer) postRoom(); });
  window.MgsRoom.on('started', () => {
    root.hidden = true; hud.hidden = false; $('#lan-hud-panel').hidden = true; nativeImmersive(true);
    muted = false; allView = false; updateHud();
    clearInterval(statsTimer);
    statsTimer = setInterval(() => {
      const st = window.MgsRoom.stats();
      slow.hidden = !(st && !st.waiting && st.stalled > 30);
      if (!slow.hidden) slow.textContent = T('slow');
    }, 500);
  });
  window.MgsRoom.on('ended', (info) => {
    clearInterval(statsTimer); slow.hidden = true;
    say(T(info && info.reason === 'kicked' ? 'kicked' : 'host_left'), 6000);
    show('home');
  });
  window.MgsRoom.on('desync', () => say(T('resynced'), 2500));
  window.MgsRoom.on('status', (s) => { if (s.kind === 'left') say(`${s.name || 'P' + (s.seat + 1)} ${T('player_left')}`); });

  // ---- HUD ----------------------------------------------------------------------------
  $('#lan-hud-btn').onclick = () => { const p = $('#lan-hud-panel'); p.hidden = !p.hidden; updateHud(); };
  window.mgsOpenMenu = () => { const p = $('#lan-hud-panel'); p.hidden = !p.hidden; updateHud(); };
  $('#hud-controls').onclick = () => { $('#lan-hud-panel').hidden = true; window.mgsBridge.openRemap(T('controls_title')); };
  $('#hud-touch').onclick = () => { $('#lan-hud-panel').hidden = true; window.mgbaTouch && window.mgbaTouch.startEdit(); };
  $('#hud-mute').onclick = () => { muted = !muted; window.mgsBridge.setMuted(muted); updateHud(); };
  $('#hud-full').onclick = () => {
    const el = document.documentElement;
    try {
      if (document.fullscreenElement) document.exitFullscreen();
      else (el.requestFullscreen || el.webkitRequestFullscreen || (() => {})).call(el);
    } catch (_) {}
    $('#lan-hud-panel').hidden = true;
  };
  $('#hud-leave').onclick = () => {
    if (!confirm(T('leave_confirm'))) return;
    clearInterval(statsTimer); slow.hidden = true;
    window.MgsRoom.leave(); stopHot();
    show('home');
  };

  // ---- save states (shared with everybody in the room) -------------------------------------
  let slot = 1; try { slot = Number(localStorage.getItem('mgs_slot')) || 1; } catch (_) {}
  function renderSlots() { hud.querySelectorAll('#hud-slots button').forEach((b) => b.classList.toggle('on', Number(b.dataset.slot) === slot)); }
  renderSlots();
  $('#hud-slots').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; slot = Number(b.dataset.slot); try { localStorage.setItem('mgs_slot', String(slot)); } catch (_) {} renderSlots(); };
  const doSave = () => window.MgsRoom.saveState(slot);
  let armTimer = 0, armed = false;
  function doLoad(btns) {
    // Loading replaces everybody's progress: ask for a second tap/press first.
    if (!armed) {
      armed = true; say(T('ss_confirm'), 2800);
      btns.forEach((b) => b.classList.add('warn'));
      armTimer = setTimeout(() => { armed = false; btns.forEach((b) => b.classList.remove('warn')); }, 3000);
      return;
    }
    clearTimeout(armTimer); armed = false; btns.forEach((b) => b.classList.remove('warn'));
    window.MgsRoom.loadState(slot);
  }
  const loadBtns = () => [$('#hud-qload'), $('#hud-load')];
  $('#hud-qsave').onclick = doSave;
  $('#hud-qload').onclick = () => doLoad(loadBtns());
  $('#hud-save').onclick = () => { doSave(); $('#lan-hud-panel').hidden = true; };
  $('#hud-load').onclick = () => doLoad(loadBtns());
  window.addEventListener('keydown', (e) => {
    if (hud.hidden) return;
    if (e.key === 'F5') { e.preventDefault(); doSave(); }
    else if (e.key === 'F8') { e.preventDefault(); doLoad(loadBtns()); }
  });
  window.MgsRoom.on('ss', (ev) => {
    const by = ev.by ? ' — ' + ev.by : '';
    if (ev.ev === 'saved') say('💾 ' + T('ss_saved').replace('{n}', ev.slot) + by, 2500);
    else if (ev.ev === 'loaded') say('📂 ' + T('ss_loaded').replace('{n}', ev.slot) + by, 3000);
    else if (ev.ev === 'fail') say('⚠ ' + T(ev.why === 'empty' ? 'ss_empty' : ev.why === 'mismatch' ? 'ss_mismatch' : 'ss_fail').replace('{n}', ev.slot || ''), 3500);
  });

  // ---- continue from a save (create screen) ---------------------------------------------------
  let resumeSlot = null;
  async function refreshResume() {
    const box = $('#c-resume-box'), list = $('#c-resume'); resumeSlot = null;
    await window.MgsRoom.useSave('', 0, null);
    if (!romFile) { box.hidden = true; return; }
    const crc = window.MgsRoom.crc32(romFile.bytes);
    let saves = []; try { saves = await window.MgsRoom.listSaves(romFile.name, crc); } catch (_) {}
    if (!saves.length) { box.hidden = true; return; }
    box.hidden = false;
    const fmt = (t) => { try { return new Date(t).toLocaleString(window.MgsI18n.lang === 'ar' ? 'ar-EG' : undefined, { dateStyle: 'short', timeStyle: 'short' }); } catch (_) { return ''; } };
    list.innerHTML = `<button class="on" data-slot="">${T('resume_new')}</button>` + saves.map((s) =>
      `<button data-slot="${s.slot}" data-players="${s.players}">${s.slot === 'auto' ? T('resume_auto') : T('slot_lbl') + ' ' + s.slot}<small>${s.players}P · ${fmt(s.mtime)}</small></button>`).join('');
    list.onclick = async (e) => {
      const b = e.target.closest('button'); if (!b) return;
      list.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
      if (b.dataset.slot === '') { resumeSlot = null; await window.MgsRoom.useSave(romFile.name, crc, null); return; }
      resumeSlot = b.dataset.slot === 'auto' ? 'auto' : Number(b.dataset.slot);
      await window.MgsRoom.useSave(romFile.name, crc, resumeSlot);
      setPlayers(Number(b.dataset.players));
    };
  }
  window.MgsI18n && document.addEventListener('mgs-lang', () => { if (screen === 'create') refreshResume(); });

  // ---- settings: save files -----------------------------------------------------------------
  async function renderSaves() {
    const S = window.MgsStore; if (!S) return;
    $('#s-saves-where').textContent = S.kind === 'browser' ? T('saves_where_browser') : T('saves_where') + ' ' + S.where;
    let files = []; try { files = await S.list(); } catch (_) {}
    const list = $('#s-saves-list');
    list.innerHTML = files.length ? files.map((f) => `<div class="lan-file-row"><span title="${f.name}">${f.name.replace(/^GBA Link Party - /, '').replace(/\.glpstate$/, '')}</span>${S.kind === 'browser' ? `<button data-x="${encodeURIComponent(f.name)}">⬇</button>` : ''}<button data-d="${encodeURIComponent(f.name)}">🗑</button></div>`).join('') : `<p class="lan-tip">${T('saves_none')}</p>`;
    list.onclick = async (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.x) await S.exportFile(decodeURIComponent(b.dataset.x));
      if (b.dataset.d && confirm(T('saves_del'))) { await S.del(decodeURIComponent(b.dataset.d)); renderSaves(); }
    };
  }
  $('#s-import').onclick = () => $('#s-import-input').click();
  $('#s-import-input').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    try { await window.MgsStore.importBytes(f.name, new Uint8Array(await f.arrayBuffer())); say('✔ ' + f.name, 2500); renderSaves(); }
    catch (_) { say(T('ss_fail'), 3000); }
  };

  // ---- hotspot / Wi-Fi choice + automatic host discovery -------------------------------------
  const NET = window.MgsNet || { caps: {}, discover: async () => [], startHotspot: async () => ({ ok: false }), stopHotspot: async () => {}, openWifi: async () => {} };
  let netMode = 'wifi', hotInfo = null;
  $('#c-net').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; netMode = b.dataset.net; root.querySelectorAll('#c-net button').forEach((x) => x.classList.toggle('on', x === b)); };
  function stopHot() { endAnnounce(); if (hotInfo) { hotInfo = null; NET.stopHotspot(); } $('#h-hot').hidden = true; }
  let finding = false;
  window.mgsFindHosts = () => findHosts();
  async function findHosts() {
    if (!NET.caps.discover || finding) return;
    finding = true;
    const box = $('#j-found');
    box.innerHTML = `<p class="lan-tip">${T('searching')}</p>`;
    let list = []; try { list = await NET.discover(); } catch (_) {}
    finding = false;
    if (screen !== 'join') return;
    box.innerHTML = list.length
      ? list.map((h) => `<button data-addr="${h.ip}:${h.port}">📡 ${h.ip}:${h.port}${h.name ? '<small>' + h.name + '</small>' : ''}</button>`).join('')
      : `<p class="lan-tip">${T('found_none')}</p>`;
    $('#j-wifi').hidden = !(NET.caps.wifi && !list.length);
    const cur = $('#j-srv').value.trim();
    if (list.length && (!cur || !list.some((h) => cur === h.ip + ':' + h.port))) {
      const h = list[0]; $('#j-srv').value = h.ip + ':' + h.port;
      try { localStorage.setItem('mgs_srv', $('#j-srv').value); } catch (_) {}
      applyServer(); refreshRooms();
    }
    box.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.addr === $('#j-srv').value.trim()));
  }
  $('#j-found').onclick = (e) => {
    const b = e.target.closest('button'); if (!b) return;
    $('#j-srv').value = b.dataset.addr; try { localStorage.setItem('mgs_srv', b.dataset.addr); } catch (_) {}
    applyServer(); refreshRooms();
    $('#j-found').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
  };
  $('#j-wifi').onclick = () => NET.openWifi();
  document.addEventListener('visibilitychange', () => { if (!document.hidden && screen === 'join') findHosts(); }); // back from Wi-Fi settings

  // ---- instant rooms: everything on the network that is hosting shows up by itself ---------------
  let nearbySig = '';
  const escH = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  async function pollNearby() {
    if (document.hidden || (screen !== 'home' && screen !== 'join')) return;
    let hosts = []; try { hosts = await NET.hosts(); } catch (_) {}
    const rooms = hosts.filter((h) => h.room && h.room.code && !h.room.started);
    const sig = JSON.stringify(rooms) + window.MgsI18n.lang;
    if (sig === nearbySig) return;
    nearbySig = sig;
    const html = rooms.map((h) => `<button class="nearby" data-ip="${escH(h.ip)}" data-port="${h.port}" data-code="${escH(h.room.code)}" data-same="${h.same ? 1 : ''}"><span>🎮 <b>${escH(h.room.name || h.name || '')}</b><small>${escH(h.room.game || '')}</small></span><span>${h.room.taken || 1}/${h.room.players || '?'} ▶</span></button>`).join('');
    $('#home-rooms').hidden = !rooms.length;
    $('#home-rooms-list').innerHTML = html;
    if (screen === 'join' && NET.caps.hosts) $('#j-rooms').innerHTML = html || `<p class="lan-tip">${T('none_found')}</p>`;
  }
  async function quickJoin(b) {
    if (!b.dataset.same) {
      const addr = b.dataset.ip + ':' + b.dataset.port;
      $('#j-srv').value = addr; try { localStorage.setItem('mgs_srv', addr); } catch (_) {}
      window.MgsSetServer(addr);
    }
    if (!$('#j-name').value.trim()) $('#j-name').value = savedName() || T('guest_default');
    joinCode(b.dataset.code);
  }
  $('#home-rooms-list').onclick = (e) => { const b = e.target.closest('button.nearby'); if (b) quickJoin(b); };
  $('#j-rooms').addEventListener('click', (e) => { const b = e.target.closest('button.nearby'); if (b) quickJoin(b); });
  setInterval(pollNearby, 800); setTimeout(pollNearby, 150);

  // ---- tell the network about the room we host (beacon + /info carry it) ---------------------------
  let roomTimer = 0;
  const roomBase = () => (nativeInfo ? 'http://127.0.0.1:' + nativeInfo.port : '');
  function postRoom(closed) {
    const S = window.MgsRoom.state;
    const body = closed ? { closed: true } : { code: S.code, name: (S.seats[0] && S.seats[0].name) || 'Host', game: S.romName, players: S.players, taken: S.seats.filter((s, i) => i === 0 || s.connected).length, started: !!S.started };
    try { fetch(roomBase() + '/room', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(body) }).catch(() => {}); } catch (_) {}
  }
  function announceRoom() { clearInterval(roomTimer); postRoom(); roomTimer = setInterval(postRoom, 4000); }
  function endAnnounce() { clearInterval(roomTimer); roomTimer = 0; postRoom(true); }

  // ---- settings (performance) ------------------------------------------------------------
  function renderSettings() {
    const P = window.mgsPerf;
    root.querySelectorAll('#lan-app [data-s="settings"] .lan-seg').forEach((g) => {
      g.querySelectorAll('button').forEach((b) => b.classList.toggle('on', String(P[g.dataset.k]) === b.dataset.v));
    });
    root.querySelectorAll('#lan-app [data-s="settings"] .lan-switch').forEach((b) => {
      const on = !!P[b.dataset.k]; b.classList.toggle('on', on); b.setAttribute('aria-checked', on ? 'true' : 'false');
    });
  }
  $('#go-settings').onclick = () => { show('settings'); renderSettings(); renderSaves(); };
  root.querySelector('[data-s="settings"]').addEventListener('click', (e) => {
    const P = window.mgsPerf;
    const sw = e.target.closest('.lan-switch');
    if (sw) { P[sw.dataset.k] = !P[sw.dataset.k]; window.mgsPerfSave(); renderSettings(); return; }
    const b = e.target.closest('.lan-seg button');
    if (b) { const k = b.parentElement.dataset.k; P[k] = (k === 'audio') ? b.dataset.v : Number(b.dataset.v); window.mgsPerfSave(); renderSettings(); }
  });

  // ---- boot --------------------------------------------------------------------------------
  const isNativeApp = (() => {
    try { if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) return true; } catch (_) {}
    try { if (window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() !== 'web') return true; } catch (_) {}
    // Android WebView ("; wv)") served from the bundled assets (http://localhost, no port)
    return /; wv\)/.test(navigator.userAgent) || (location.hostname === 'localhost' && !location.port);
  })();
  window.mgsNativeApp = isNativeApp;
  const hasServer = !!window.MgsNative;
  window.mgsHasServer = hasServer;
  if (isNativeApp && !hasServer) {
    const gc = $('#go-create'); gc.hidden = true; gc.style.display = 'none';
    $('#go-join').classList.add('primary');
  }
  if (window.mgsDesktop || isNativeApp) { $('#j-srv-box').hidden = false; try { $('#j-srv').value = localStorage.getItem('mgs_srv') || ''; } catch (_) {} }
  const nm = savedName();
  $('#c-name').value = nm; $('#j-name').value = nm;
  setPlayers(2); fileLabel();
  window.MgsI18n.apply(); show('home');
  const urlCode = (() => { try { return new URLSearchParams(location.search).get('room'); } catch (_) { return null; } })();
  if (urlCode && /^\d{4}$/.test(urlCode)) { show('join'); $('#j-code').value = urlCode; }
})();
