/* Simple LAN UI: home → create/join → lobby → game. Talks to MgsRoom + mgsBridge. */
(function () {
  const T = (k) => window.MgsI18n.t(k);
  const SEAT_COLORS = ['#ff6b6b', '#5aa9ff', '#7bd88f', '#ffd166'];
  const $ = (sel, root) => (root || document).querySelector(sel);
  let screen = 'home';
  let romFile = null;          // host: { bytes, name }
  let players = 2;
  let guestRom = null;         // guest: picked file (for "I have it")
  let roomsTimer = null, statsTimer = null, toastTimer = null;
  let muted = false, allView = false;

  const root = document.createElement('div');
  root.id = 'lan-app';
  root.innerHTML = `
  <section class="lan-screen" data-s="home"><div class="lan-wrap">
    <div class="lan-top"><span></span><button class="lan-pill" id="lan-lang"></button></div>
    <h1 class="lan-h1" data-i18n="title"></h1>
    <p class="lan-sub" data-i18n="tagline"></p>
    <button class="lan-big primary" id="go-create"><strong data-i18n="create"></strong><span data-i18n="create_sub"></span></button>
    <button class="lan-big" id="go-join"><strong data-i18n="join"></strong><span data-i18n="join_sub"></span></button>
    <button class="lan-link" id="go-solo" data-i18n="solo"></button>
    <p class="lan-tip" data-i18n="tip_wifi"></p>
  </div></section>

  <section class="lan-screen" data-s="create" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-back data-i18n="back"></button><button class="lan-pill lan-langbtn"></button></div>
    <h1 class="lan-h1" data-i18n="create"></h1>
    <div class="lan-card">
      <div><div class="lan-label" data-i18n="your_name"></div><input class="lan-input" id="c-name" maxlength="20" /></div>
      <div><div class="lan-label" data-i18n="choose_game"></div>
        <button class="lan-file" id="c-file"><span style="font-size:24px">🎮</span><span><b id="c-file-name"></b><small data-i18n="game_hint"></small></span></button>
        <input type="file" id="c-file-input" accept=".gba,.gbc,.gb,.agb,.bin,.zip" hidden /></div>
      <div><div class="lan-label" data-i18n="players"></div>
        <div class="lan-seg" id="c-players"><button data-n="2">2</button><button data-n="3">3</button><button data-n="4">4</button></div></div>
      <p class="lan-err" id="c-err"></p>
      <button class="lan-btn" id="c-make" data-i18n="make_room"></button>
    </div>
    <p class="lan-tip" data-i18n="tip_same"></p>
  </div></section>

  <section class="lan-screen" data-s="hostlobby" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-leave data-i18n="leave"></button><button class="lan-pill lan-langbtn"></button></div>
    <div class="lan-card">
      <div class="lan-label" data-i18n="room_code"></div>
      <div class="lan-code" id="h-code"></div>
      <div class="lan-qr"><canvas id="h-qr"></canvas></div>
      <div class="lan-label" style="text-align:center" data-i18n="scan"></div>
      <div class="lan-url" id="h-url"></div>
    </div>
    <ul class="lan-roster" id="h-roster"></ul>
    <p class="lan-tip" id="h-hint"></p>
    <button class="lan-btn" id="h-start" data-i18n="start"></button>
  </div></section>

  <section class="lan-screen" data-s="join" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-back data-i18n="back"></button><button class="lan-pill lan-langbtn"></button></div>
    <h1 class="lan-h1" data-i18n="join"></h1>
    <div class="lan-card">
      <div><div class="lan-label" data-i18n="your_name"></div><input class="lan-input" id="j-name" maxlength="20" /></div>
      <div id="j-srv-box" hidden><div class="lan-label" data-i18n="host_addr"></div><input class="lan-input" id="j-srv" placeholder="192.168.1.5:8090" style="direction:ltr" /></div>
      <div class="lan-row"><div class="lan-label" data-i18n="open_rooms" style="flex:1;align-self:center"></div><button class="lan-pill" id="j-refresh" data-i18n="refresh" style="flex:none"></button></div>
      <div class="lan-rooms" id="j-rooms"></div>
      <div><div class="lan-label" data-i18n="enter_code"></div>
        <div class="lan-row"><input class="lan-input" id="j-code" inputmode="numeric" maxlength="4" style="direction:ltr;text-align:center;letter-spacing:.2em" /><button class="lan-btn" id="j-go" data-i18n="go" style="flex:none"></button></div></div>
      <p class="lan-err" id="j-err"></p>
    </div>
  </div></section>

  <section class="lan-screen" data-s="guestlobby" hidden><div class="lan-wrap">
    <div class="lan-top"><button class="lan-pill" data-leave data-i18n="leave"></button><button class="lan-pill lan-langbtn"></button></div>
    <div class="lan-card"><div class="lan-label" data-i18n="room_code"></div><div class="lan-code" id="g-code" style="font-size:40px"></div>
      <div class="lan-sub" id="g-game" style="text-align:center"></div></div>
    <ul class="lan-roster" id="g-roster"></ul>
    <div id="g-choose" class="lan-card">
      <button class="lan-big primary" id="g-have"><strong data-i18n="i_have"></strong><span data-i18n="i_have_sub"></span></button>
      <button class="lan-big" id="g-dont"><strong data-i18n="i_dont"></strong><span data-i18n="i_dont_sub"></span></button>
      <input type="file" id="g-file-input" accept=".gba,.gbc,.gb,.agb,.bin,.zip" hidden />
      <p class="lan-err" id="g-err"></p>
    </div>
    <p class="lan-note" id="g-wait" hidden data-i18n="waiting_host"></p>
  </div></section>`;
  document.body.appendChild(root);

  const hud = document.createElement('div');
  hud.id = 'lan-hud'; hud.hidden = true;
  hud.innerHTML = `<button id="lan-hud-btn" aria-label="menu">☰</button>
    <div id="lan-hud-panel" hidden>
      <button id="hud-controls"></button><button id="hud-touch"></button><button id="hud-mute"></button><button id="hud-view"></button><button id="hud-full"></button><button id="hud-leave" class="danger"></button>
    </div>`;
  document.body.appendChild(hud);
  const toast = document.createElement('div'); toast.id = 'lan-toast'; toast.hidden = true; document.body.appendChild(toast);
  const slow = document.createElement('div'); slow.id = 'lan-slow'; slow.hidden = true; document.body.appendChild(slow);
  const homeBtn = document.createElement('button'); homeBtn.id = 'lan-home-btn'; homeBtn.className = 'lan-pill'; homeBtn.hidden = true; homeBtn.textContent = '⌂'; document.body.appendChild(homeBtn);

  document.body.classList.add('lan-ui'); // hides the old menu bar while the party UI is active

  function nativeImmersive(on) { try { if (window.MgsNative && window.MgsNative.immersive) window.MgsNative.immersive(!!on); } catch (_) {} }
  function show(name) {
    nativeImmersive(false);
    screen = name;
    root.hidden = false;
    root.querySelectorAll('.lan-screen').forEach((s) => { s.hidden = s.dataset.s !== name; });
    hud.hidden = true;
    clearInterval(roomsTimer);
    if (name === 'join') { refreshRooms(); roomsTimer = setInterval(refreshRooms, 3000); }
    renderLangButtons();
    window.MgsI18n.apply(root);
    updateHud();
    root.scrollTop = 0;
  }
  function renderLangButtons() {
    const l = T('lang');
    $('#lan-lang').textContent = l;
    root.querySelectorAll('.lan-langbtn').forEach((b) => { b.textContent = l; });
  }
  function say(msg, ms) {
    toast.textContent = msg; toast.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { toast.hidden = true; }, ms || 3500);
  }
  function updateHud() {
    $('#hud-mute').textContent = muted ? '🔇 ' + T('unmute') : '🔊 ' + T('mute');
    $('#hud-view').textContent = '🖥 ' + (allView ? T('view_me') : T('view_all'));
    $('#hud-full').textContent = '⛶ ' + T('fullscreen');
    $('#hud-controls').textContent = '⌨ ' + T('controls');
    $('#hud-touch').textContent = '🎮 ' + T('touch_edit');
    $('#hud-touch').style.display = (navigator.maxTouchPoints > 0 || window.mgbaTouch) ? '' : 'none';
    $('#hud-leave').textContent = '⏏ ' + T('leave');
  }
  document.addEventListener('mgs-lang', () => { renderLangButtons(); updateHud(); renderRoster(); renderChooseState(); fileLabel(); });

  // ---- wiring: generic ------------------------------------------------------
  root.addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.id === 'lan-lang' || t.classList.contains('lan-langbtn')) window.MgsI18n.toggle();
    else if (t.hasAttribute('data-back')) show('home');
    else if (t.hasAttribute('data-leave')) { window.MgsRoom.leave(); show('home'); }
  });
  $('#go-create').onclick = () => show('create');
  $('#go-join').onclick = () => show('join');
  $('#go-solo').onclick = () => {
    root.hidden = true; document.body.classList.remove('lan-ui'); homeBtn.hidden = false;
  };
  homeBtn.onclick = () => { homeBtn.hidden = true; document.body.classList.add('lan-ui'); show('home'); };

  // ---- create (host) --------------------------------------------------------
  function fileLabel() {
    $('#c-file-name').textContent = romFile ? `${T('chosen')}: ${romFile.name}` : T('pick_file');
    $('#c-file').classList.toggle('has', !!romFile);
  }
  function setPlayers(n) {
    players = n;
    root.querySelectorAll('#c-players button').forEach((b) => b.classList.toggle('on', Number(b.dataset.n) === n));
  }
  $('#c-players').onclick = (e) => { const b = e.target.closest('button'); if (b) setPlayers(Number(b.dataset.n)); };
  $('#c-file').onclick = () => $('#c-file-input').click();
  $('#c-file-input').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    romFile = { bytes: new Uint8Array(await f.arrayBuffer()), name: f.name.replace(/\.[^.]+$/, '') };
    fileLabel();
  };
  const savedName = () => { try { return localStorage.getItem('mgs_name') || ''; } catch (_) { return ''; } };
  const saveName = (v) => { try { localStorage.setItem('mgs_name', v); } catch (_) {} };

  $('#c-make').onclick = async () => {
    const err = $('#c-err'); err.textContent = '';
    if (!romFile) { err.textContent = T('choose_game'); return; }
    if (typeof WebAssembly === 'undefined') { err.textContent = T('unsupported'); return; }
    const name = $('#c-name').value.trim() || 'Host'; saveName(name);
    $('#c-make').disabled = true;
    try {
      if (!window.mgsBridge) throw new Error('mgsBridge missing — old cached page? Press Ctrl+F5');
      await window.mgsBridge.ready();
    } catch (e2) { console.error(e2); err.textContent = T('err_engine') + ' [' + (e2 && e2.message || e2) + ']'; $('#c-make').disabled = false; return; }
    if (window.mgsHasServer) {
      try {
        nativeInfo = JSON.parse(window.MgsNative.startServer());
        if (!nativeInfo || !nativeInfo.port) throw new Error('no port');
        window.MgsSetServer('127.0.0.1:' + nativeInfo.port);
      } catch (e4) { console.error(e4); err.textContent = T('err_net') + ' — ' + T('err_phone_server'); $('#c-make').disabled = false; return; }
    }
    try {
      const code = await window.MgsRoom.createRoom({ players, romBytes: romFile.bytes, romName: romFile.name, name });
      showHostLobby(code);
    } catch (e3) { err.textContent = T('err_net') + (window.mgsNativeApp ? ' — ' + T('err_native_host') : ''); }
    $('#c-make').disabled = false;
  };

  let nativeInfo = null;
  async function lanBase() {
    if (nativeInfo) return 'http://' + (nativeInfo.ips && nativeInfo.ips[0] ? nativeInfo.ips[0] : '127.0.0.1') + ':' + nativeInfo.port + '/';
    let host = location.host;
    if (/^(localhost|127\.|\[::1\])/.test(location.hostname)) {
      try {
        const info = await (await fetch('/info', { cache: 'no-store' })).json();
        if (info.ips && info.ips[0]) host = info.ips[0] + ':' + info.port;
      } catch (_) {}
    }
    return `${location.protocol}//${host}/`;
  }
  async function showHostLobby(code) {
    show('hostlobby');
    $('#h-code').textContent = code;
    const url = (await lanBase()) + '?room=' + code;
    $('#h-url').textContent = url + (nativeInfo ? '\n' + T('app_addr') + ' ' + (nativeInfo.ips && nativeInfo.ips[0] || '?') + ':' + nativeInfo.port : '');
    $('#h-url').style.whiteSpace = 'pre-line';
    try {
      window.QRCode.toCanvas($('#h-qr'), url, { margin: 1, width: 176 }, () => {});
    } catch (_) {}
    renderRoster();
  }

  // ---- roster ----------------------------------------------------------------
  function statusText(r) {
    if (r.seat === 0) return T('host_game');
    if (!r.connected && !r.name) return T('empty');
    if (!r.connected) return '—';
    if (r.mode === 'sim') return T('ready_sim');
    if (r.mode === 'stream') return T('ready_stream');
    return T('not_ready');
  }
  function renderRoster() {
    const S = window.MgsRoom.state;
    const roster = S.roster && S.roster.length ? S.roster : [];
    const total = S.players || roster.length;
    const rows = [];
    for (let i = 0; i < total; i++) {
      const r = roster[i] || { seat: i, name: '', connected: false };
      const empty = !r.connected && !r.name;
      const isMe = S.role === 'guest' ? i === S.mySeat : i === 0;
      rows.push(`<li class="${empty ? 'empty' : ''}"><span class="dot" style="background:${SEAT_COLORS[i]}"></span>
        <span class="nm">${empty ? '…' : esc(r.name || 'P' + (i + 1))}${isMe ? ' · ' + T('you') : ''}</span>
        <span class="st">${statusText(r)}</span></li>`);
    }
    const html = rows.join('');
    $('#h-roster').innerHTML = html; $('#g-roster').innerHTML = html;
    if (S.role === 'host') {
      const ok = window.MgsRoom.canStart();
      $('#h-start').disabled = !ok;
      const guests = roster.slice(1).filter((r) => r.connected);
      $('#h-hint').textContent = !guests.length ? T('need_one') : (ok ? '' : T('wait_ready'));
    }
  }
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  $('#h-start').onclick = async () => {
    $('#h-start').disabled = true;
    try { await window.MgsRoom.start(); }
    catch (e) { console.error(e); say(T('err_rom'), 5000); window.MgsRoom.leave(); show('home'); }
  };

  // ---- join (guest) ------------------------------------------------------------
  function applyServer() { const v = $('#j-srv').value.trim(); if (v) window.MgsSetServer(v); }
  $('#j-srv').onchange = () => { applyServer(); try { localStorage.setItem('mgs_srv', $('#j-srv').value.trim()); } catch (_) {} refreshRooms(); };
  async function refreshRooms() {
    applyServer();
    const list = await window.MgsRoom.listRooms();
    if (screen !== 'join') return;
    const box = $('#j-rooms');
    box.innerHTML = list.length
      ? list.map((c) => `<button class="lan-room" data-code="${c}"><b>${c}</b><span>▶</span></button>`).join('')
      : `<p class="lan-tip">${T('none_found')}</p>`;
  }
  $('#j-refresh').onclick = refreshRooms;
  $('#j-rooms').onclick = (e) => { const b = e.target.closest('.lan-room'); if (b) joinCode(b.dataset.code); };
  $('#j-go').onclick = () => joinCode($('#j-code').value.trim());
  $('#j-code').onkeydown = (e) => { if (e.key === 'Enter') joinCode($('#j-code').value.trim()); };

  async function joinCode(code) {
    applyServer();
    const err = $('#j-err'); err.textContent = '';
    if (isNativeApp && !$('#j-srv').value.trim()) { err.textContent = T('need_addr'); return; }
    if (!/^\d{4}$/.test(code)) { err.textContent = T('err_room'); return; }
    const name = $('#j-name').value.trim() || 'Guest'; saveName(name);
    err.textContent = T('connecting');
    try {
      const info = await window.MgsRoom.joinRoom(code, name);
      err.textContent = '';
      guestRom = null;
      $('#g-code').textContent = code;
      $('#g-game').textContent = '🎮 ' + (info.romName || '');
      $('#g-err').textContent = '';
      show('guestlobby');
      renderChooseState();
      renderRoster();
    } catch (e) {
      err.textContent = e && e.type === 'full' ? (e.why === 'started' ? T('err_started') : T('err_full')) : T('err_room');
    }
  }

  function renderChooseState() {
    const S = window.MgsRoom.state;
    const chosen = S.myMode;
    $('#g-choose').hidden = !!chosen;
    $('#g-wait').hidden = !chosen;
  }
  $('#g-have').onclick = async () => {
    if (typeof WebAssembly === 'undefined') { $('#g-err').textContent = T('unsupported'); return; }
    $('#g-file-input').click();
  };
  $('#g-file-input').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const err = $('#g-err'); err.textContent = '';
    try { if (!window.mgsBridge) throw new Error('mgsBridge missing — press Ctrl+F5'); await window.mgsBridge.ready(); } catch (e2) { err.textContent = T('err_engine') + ' [' + (e2 && e2.message || e2) + ']'; return; }
    const bytes = new Uint8Array(await f.arrayBuffer());
    const r = window.MgsRoom.chooseRom(bytes, f.name);
    if (!r.ok) { err.textContent = T('wrong_rom'); return; }
    renderChooseState();
  };
  $('#g-dont').onclick = () => { window.MgsRoom.chooseStream(); renderChooseState(); };

  // ---- room events -----------------------------------------------------------------
  window.MgsRoom.on('roster', () => { renderRoster(); renderChooseState(); });
  window.MgsRoom.on('started', () => {
    root.hidden = true; hud.hidden = false; $('#lan-hud-panel').hidden = true; nativeImmersive(true);
    muted = false; allView = false; updateHud();
    clearInterval(statsTimer);
    statsTimer = setInterval(() => {
      const st = window.MgsRoom.stats();
      slow.hidden = !(st && !st.waiting && st.stalled > 30);
      if (!slow.hidden) slow.textContent = T('slow');
    }, 500);
  });
  window.MgsRoom.on('ended', (info) => {
    clearInterval(statsTimer); slow.hidden = true;
    say(T(info && info.reason === 'kicked' ? 'kicked' : 'host_left'), 6000);
    show('home');
  });
  window.MgsRoom.on('desync', () => say(T('resynced'), 2500));
  window.MgsRoom.on('status', (s) => { if (s.kind === 'left') say(`${s.name || 'P' + (s.seat + 1)} ${T('player_left')}`); });

  // ---- HUD ----------------------------------------------------------------------------
  $('#lan-hud-btn').onclick = () => { const p = $('#lan-hud-panel'); p.hidden = !p.hidden; updateHud(); };
  window.mgsOpenMenu = () => { const p = $('#lan-hud-panel'); p.hidden = !p.hidden; updateHud(); };
  $('#hud-controls').onclick = () => { $('#lan-hud-panel').hidden = true; window.mgsBridge.openRemap(T('controls_title')); };
  $('#hud-touch').onclick = () => { $('#lan-hud-panel').hidden = true; window.mgbaTouch && window.mgbaTouch.startEdit(); };
  $('#hud-mute').onclick = () => { muted = !muted; window.mgsBridge.setMuted(muted); updateHud(); };
  $('#hud-view').onclick = () => { allView = !allView; window.mgsBridge.setView(allView ? 'grid' : 'focus'); updateHud(); };
  $('#hud-full').onclick = () => {
    const el = document.documentElement;
    try {
      if (document.fullscreenElement) document.exitFullscreen();
      else (el.requestFullscreen || el.webkitRequestFullscreen || (() => {})).call(el);
    } catch (_) {}
    $('#lan-hud-panel').hidden = true;
  };
  $('#hud-leave').onclick = () => {
    if (!confirm(T('leave_confirm'))) return;
    clearInterval(statsTimer); slow.hidden = true;
    window.MgsRoom.leave();
    show('home');
  };

  // ---- boot --------------------------------------------------------------------------------
  const isNativeApp = (() => {
    try { if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) return true; } catch (_) {}
    try { if (window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform() !== 'web') return true; } catch (_) {}
    // Android WebView ("; wv)") served from the bundled assets (http://localhost, no port)
    return /; wv\)/.test(navigator.userAgent) || (location.hostname === 'localhost' && !location.port);
  })();
  window.mgsNativeApp = isNativeApp;
  const hasServer = !!window.MgsNative;
  window.mgsHasServer = hasServer;
  if (isNativeApp && !hasServer) {
    const gc = $('#go-create'); gc.hidden = true; gc.style.display = 'none';
    $('#go-join').classList.add('primary');
  }
  if (window.mgsDesktop || isNativeApp) { $('#j-srv-box').hidden = false; try { $('#j-srv').value = localStorage.getItem('mgs_srv') || ''; } catch (_) {} }
  const nm = savedName();
  $('#c-name').value = nm; $('#j-name').value = nm;
  setPlayers(2); fileLabel();
  window.MgsI18n.apply(); show('home');
  const urlCode = (() => { try { return new URLSearchParams(location.search).get('room'); } catch (_) { return null; } })();
  if (urlCode && /^\d{4}$/.test(urlCode)) { show('join'); $('#j-code').value = urlCode; }
})();
