/* Save-file storage for "GBA Link Party".
 * Every save is a file named after the program:  "GBA Link Party - <game> [crc] - slot 1.glpstate"
 *  - Windows / Linux app: real files in  Documents/GBA Link Party/Saves
 *  - Android app:         real files in  Android/data/party.gba.link/files/GBA Link Party/Saves
 *  - browser:             kept inside the browser (IndexedDB) + Export/Import buttons
 * Container: "GLPS" | u32 headerLength | JSON header | state blob.
 */
(function () {
  const APP = 'GBA Link Party';
  const EXT = '.glpstate';

  const safe = (s) => String(s || 'game').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 60) || 'game';
  function fileName(rom, crc, slot) {
    const c = (crc >>> 0).toString(16).padStart(8, '0');
    return `${APP} - ${safe(rom)} [${c}] - ${slot === 'auto' ? 'autosave' : 'slot ' + slot}${EXT}`;
  }

  // ---- container ---------------------------------------------------------------------------
  function encode(header, states) {
    const sizes = states.map((s) => s.length);
    const h = new TextEncoder().encode(JSON.stringify(Object.assign({ v: 1, app: APP, sizes }, header)));
    const total = 8 + h.length + sizes.reduce((a, b) => a + b, 0);
    const out = new Uint8Array(total);
    out.set([0x47, 0x4c, 0x50, 0x53], 0);
    new DataView(out.buffer).setUint32(4, h.length, true);
    out.set(h, 8);
    let off = 8 + h.length;
    for (const s of states) { out.set(s, off); off += s.length; }
    return out;
  }
  function decode(bytes) {
    if (!bytes || bytes.length < 12 || bytes[0] !== 0x47 || bytes[1] !== 0x4c || bytes[2] !== 0x50 || bytes[3] !== 0x53) return null;
    try {
      const hl = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(4, true);
      const header = JSON.parse(new TextDecoder().decode(bytes.subarray(8, 8 + hl)));
      let off = 8 + hl; const states = [];
      for (const n of header.sizes) { states.push(bytes.slice(off, off + n)); off += n; }
      if (off > bytes.length) return null;
      return { header, states };
    } catch (_) { return null; }
  }

  // ---- backends -----------------------------------------------------------------------------
  const b64 = {
    enc(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); },
    dec(str) { const bin = atob(str); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; },
  };

  function idb() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open('GBA-Link-Party', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('saves');
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  const idbOp = async (mode, fn) => {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('saves', mode); const st = tx.objectStore('saves');
      const req = fn(st);
      tx.oncomplete = () => resolve(req && req.result);
      tx.onerror = () => reject(tx.error);
    });
  };
  const browserBackend = {
    kind: 'browser', where: 'browser',
    put: (n, u8) => idbOp('readwrite', (s) => s.put({ bytes: u8, mtime: Date.now() }, n)),
    get: async (n) => { const r = await idbOp('readonly', (s) => s.get(n)); return r ? r.bytes : null; },
    del: (n) => idbOp('readwrite', (s) => s.delete(n)),
    list: async () => {
      const db = await idb();
      return new Promise((resolve, reject) => {
        const out = []; const tx = db.transaction('saves', 'readonly');
        const c = tx.objectStore('saves').openCursor();
        c.onsuccess = () => { const cur = c.result; if (cur) { out.push({ name: cur.key, size: cur.value.bytes.length, mtime: cur.value.mtime }); cur.continue(); } };
        tx.oncomplete = () => resolve(out); tx.onerror = () => reject(tx.error);
      });
    },
  };
  const desktopBackend = (f) => ({
    kind: 'desktop', where: f.dir,
    put: (n, u8) => f.write(n, u8),
    get: async (n) => { const r = await f.read(n); return r ? new Uint8Array(r) : null; },
    del: (n) => f.del(n),
    list: () => f.list(),
  });
  const androidBackend = (N) => ({
    kind: 'android', where: (() => { try { return N.filesDir(); } catch (_) { return 'app files'; } })(),
    put: async (n, u8) => { if (N.writeFile(n, b64.enc(u8)) !== 'ok') throw new Error('write failed'); },
    get: async (n) => { const r = N.readFile(n); return r ? b64.dec(r) : null; },
    del: async (n) => { N.deleteFile(n); },
    list: async () => { try { return JSON.parse(N.listFiles()); } catch (_) { return []; } },
  });

  function backend() {
    try { if (window.mgsFiles) return desktopBackend(window.mgsFiles); } catch (_) {}
    try { if (window.MgsNative && window.MgsNative.writeFile) return androidBackend(window.MgsNative); } catch (_) {}
    return browserBackend;
  }

  const api = {
    APP, EXT, fileName, encode, decode,
    get kind() { return backend().kind; },
    get where() { return backend().where; },
    put: (n, u8) => backend().put(n, u8),
    get: (n) => backend().get(n),
    del: (n) => backend().del(n),
    list: async () => (await backend().list()).filter((f) => f.name.endsWith(EXT)).sort((a, b) => b.mtime - a.mtime),
    // browser only: hand a save to the user as a download / read one back from a file picker
    exportFile: async (n) => {
      const u8 = await backend().get(n); if (!u8) return false;
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([u8])); a.download = n; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000); return true;
    },
    importBytes: async (name, u8) => {
      const d = decode(u8); if (!d) throw new Error('not a save file');
      const n = /\.glpstate$/i.test(name) ? name : name + EXT;
      await backend().put(n, u8); return n;
    },
  };
  window.MgsStore = api;
})();
