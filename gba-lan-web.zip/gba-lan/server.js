// خادم محلي: يقدّم صفحة المحاكي + يوفّر وسيط إشارات PeerJS على الشبكة المحلية (بدون إنترنت)
const http = require('http');
const os = require('os');
const path = require('path');
const express = require('express');
const { ExpressPeerServer } = require('peer');

const app = express();
const server = http.createServer(app);

let PORT = Number(process.env.PORT) || 8090;
function lanIPs() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces()))
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  return out;
}

app.use('/peerjs', ExpressPeerServer(server, { path: '/', allow_discovery: true }));
app.post('/session_log', (_req, res) => res.sendStatus(204)); // the page's optional console capture: ignore
app.get('/info', (_req, res) => res.json({ port: PORT, ips: lanIPs() }));
app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders(res, file) {
    if (file.endsWith('.wasm')) res.setHeader('Content-Type', 'application/wasm');
    res.setHeader('Cache-Control', 'no-cache');
  },
}));

function banner(PORT) {
  console.log('\n🎮 GBA LAN شغّال (بدون إنترنت)');
  console.log(`  على هذا الجهاز:        http://localhost:${PORT}`);
  lanIPs().forEach((ip) => console.log(`  للأجهزة على نفس الشبكة: http://${ip}:${PORT}`));
  console.log('\n  ملاحظة: افتح الرابط ذو الـ IP على جهاز الهوست أيضاً (وليس localhost) حتى تعمل دعوات QR للآخرين.\n');
}

// Start listening. Returns the port actually used (tries the next ports if busy).
function start(port, quiet) {
  PORT = port || PORT;
  return new Promise((resolve, reject) => {
    let tries = 0;
    const attempt = () => {
      server.once('error', (e) => {
        if (e.code === 'EADDRINUSE' && tries++ < 20) { PORT++; attempt(); } else reject(e);
      });
      server.listen(PORT, '0.0.0.0', () => { if (!quiet) banner(PORT); resolve(PORT); });
    };
    attempt();
  });
}
module.exports = { start, lanIPs };
if (require.main === module) start();
